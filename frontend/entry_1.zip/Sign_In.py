# Sign_In.py
from tkinter import *
import Log_In

def open_sign_in_new_window(current_window=None):
    if current_window:
        current_window.destroy()  # Close Log_In window if called from there

    new_window = Tk()
    new_window.geometry("1000x600")
    new_window.configure(bg="#FFFFFF")
    new_window.title("Budget Tracker")

    canvas = Canvas(
        new_window,
        bg="#FFFFFF",
        height=600,
        width=1000,
        bd=0,
        highlightthickness=0,
        relief="ridge"
    )
    canvas.place(x=0, y=0)

    canvas.create_rectangle(0.0, 
                            0.0, 
                            500.0, 
                            600.0, 
                            fill="#9FD39C", 
                            outline=""
                            )
    
    canvas.create_rectangle(500.0, 
                            0.0, 
                            1000.0, 
                            600.0, 
                            fill="#F4F4F4", 
                            outline=""
                            )

    canvas.create_text(550.0, 
                       48.0, 
                       anchor="nw", 
                       text="Welcome!", 
                       fill="#000000", 
                       font=("Montserrat", 24 * -1, "bold")
                       )
    canvas.create_text(150.0, 
                       93.0, 
                       anchor="nw", 
                       text="Nice to see you again", 
                       fill="#333333", 
                       font=("DMSans", 20 * -1)
                       )
    
    canvas.create_text(100.0, 
                       123.0, 
                       anchor="nw", 
                       text="Welcome back", 
                       fill="#333333", 
                       font=("DMSans", 40 * -1, "bold")
                       )

    entry_image_1 = PhotoImage(file="entry_1.png")
    canvas.create_image(751.0, 
                        236.5, 
                        image=entry_image_1
                        )
    
    entry_1 = Entry(bd=0, 
                    bg="#D9D9D9", 
                    fg="#000716", 
                    highlightthickness=0
                    )
    
    entry_1.place(x=587.0, 
                  y=213.0, 
                  width=328.0, 
                  height=45.0
                  )

    entry_image_2 = PhotoImage(file="entry_2.png")
    canvas.create_image(751.0, 
                        331.5, 
                        image=entry_image_2)
    entry_2 = Entry(bd=0, 
                    bg="#D9D9D9", 
                    fg="#000716", 
                    highlightthickness=0, 
                    show="*"
                    )
    entry_2.place(x=587.0, 
                  y=308.0, 
                  width=328.0, 
                  height=45.0
                  )

    def click():
        print("hello")

    button_image_1 = PhotoImage(file="button_1.png")
    button_1 = Button(
        new_window,
        command=click,
        image=button_image_1,
        text="SIGN UP",
        font=("Inter", 20 * -1, "bold"),
        fg="#333333",
        borderwidth=0,
        highlightthickness=0,
        compound="center",
        relief="flat"
    )
    button_1.place(x=571.0, y=396.0, width=360.0, height=47.0)

    canvas.create_text(670.0, 
                       148.0, 
                       anchor="nw", 
                       text="Create Account", 
                       fill="#000000", 
                       font=("Montserrat", 20 * -1, "bold")
                       )
    
    canvas.create_text(587.0, 
                       183.0, 
                       anchor="nw", 
                       text="Username", 
                       fill="#000000", 
                       font=("Montserrat", 14 * -1)
                       )
    
    canvas.create_text(587.0, 
                       278.0, 
                       anchor="nw", 
                       text="Password", 
                       fill="#000000", 
                       font=("Montserrat", 14 * -1)
                       )

    def toggle_password():
        if show_password_var.get():
            entry_2.config(show="")
        else:
            entry_2.config(show="*")

    show_password_var = IntVar(value=0)
    show_password_checkbox = Checkbutton(
        new_window,
        text="Show Password",
        variable=show_password_var,
        command=toggle_password,
        bg="#F4F4F4",
        font=("Montserrat", 14 * -1),
        fg="#000000",
        activebackground="#F4F4F4",
        activeforeground="#000000",
        highlightthickness=0,
        bd=0,
    )
    show_password_checkbox.place(x=795, y=365)

    canvas.create_text(695.0, 
                       457.0, 
                       anchor="nw", 
                       text="Already a user?", 
                       fill="#000000", 
                       font=("Inter", 12 * -1, "normal")
                       )

    login_text_id = canvas.create_text(784.0, 
                                       457.0, 
                                       anchor="nw", 
                                       text="LOGIN", 
                                       fill="#000000", 
                                       font=("Inter", 12 * -1, "underline")
                                       )

    def on_click():
        Log_In.open_log_in_new_window(new_window)

    canvas.tag_bind(login_text_id, "<Button-1>", lambda e: on_click())
    canvas.tag_bind(login_text_id, "<Enter>", lambda e: canvas.config(cursor="hand2"))
    canvas.tag_bind(login_text_id, "<Leave>", lambda e: canvas.config(cursor=""))

    new_window.update_idletasks()
    new_window.resizable(False, False)
    new_window.mainloop()

if __name__ == "__main__":
    open_sign_in_new_window()
