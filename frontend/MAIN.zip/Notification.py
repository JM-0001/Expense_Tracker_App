import customtkinter as ctk

class NotificationHandler:
    def __init__(self, main_window):
        self.main_window = main_window
        self.notif_frame = None
        self.notif_visible = False

    def notification(self):
        # Toggle notification visibility
        if self.notif_visible:
            self.hide_notification()
        else:
            self.show_notification()

    def show_notification(self):
        if not self.notif_visible:
            self.notif_frame = ctk.CTkScrollableFrame(
                self.main_window,
                corner_radius=26,
                width=297,
                height=337,
                fg_color="#CFF6CD",
                bg_color="#9FD39C"
            )
            for x in range(10):
                ctk.CTkButton(self.notif_frame, text=f"Button {x+1}").pack(pady=10)
            self.notif_frame.place(x=615, y=80)
            self.notif_frame.lift()
            self.notif_visible = True

    def hide_notification(self):
        if self.notif_visible and self.notif_frame and self.notif_frame.winfo_exists():
            self.notif_frame.place_forget()
            self.notif_frame.destroy()
            self.notif_frame = None
        self.notif_visible = False

    def lift_notification(self):
        if self.notif_visible and self.notif_frame and self.notif_frame.winfo_exists():
            self.notif_frame.lift()

