import customtkinter as ctk
from pathlib import Path
from PIL import Image

ASSETS_PATH = Path(__file__).parent / "assets_settings"

class SettingsHandler:
    def __init__(self, main_window):
        self.main_window = main_window
        self.settings_frame_features = None
        self.settings_visible = False
        self.images = {}  # Store image references

    def is_visible(self):
        return self.settings_visible and self.settings_frame_features is not None \
               and self.settings_frame_features.winfo_exists()

    def settings(self):
        if self.is_visible():
            self.hide_settings()
        else:
            self.show_settings()

    def show_settings(self):
        # If a settings frame exists, destroy it before showing main settings
        if self.settings_frame_features and self.settings_frame_features.winfo_exists():
            self.settings_frame_features.destroy()

        self.settings_frame_features = ctk.CTkFrame(
            self.main_window,
            corner_radius=26,
            width=339,
            height=340,
            fg_color="#CFF6CD",
            bg_color="#9FD39C"
        )
        self.settings_frame_features.place(x=615, y=80)
        self.settings_frame_features.lift()
        self.settings_visible = True

        # Load and place images
        self.images['image_1'] = self.load_image("image_1.png", (70, 70))
        label_image_1 = ctk.CTkLabel(self.settings_frame_features, text="", image=self.images['image_1'])
        label_image_1.place(x=20, y=220)

        logout_label = ctk.CTkLabel(self.settings_frame_features, text="Logout", font=("Poppins", 16 * -1, "bold"))
        logout_label.place(x=104, y=240)

        self.images['image_2'] = self.load_image("image_2.png", (70, 70))
        label_image_2 = ctk.CTkLabel(self.settings_frame_features, text="", image=self.images['image_2'])
        label_image_2.place(x=20, y=130)

        settings_label = ctk.CTkLabel(self.settings_frame_features, text="Settings", font=("Poppins", 16 * -1, "bold"))
        settings_label.place(x=104, y=150)

        self.images['image_3'] = self.load_image("image_3.png", (50, 50))
        label_image_3 = ctk.CTkLabel(self.settings_frame_features, text="", image=self.images['image_3'])
        label_image_3.place(x=147, y=30)

        user_label = ctk.CTkLabel(self.settings_frame_features, text="USER", font=("Poppins", 13, "bold"))
        user_label.place(x=153, y=80)

        # Bind events
        logout_label.bind("<Button-1>", lambda e: self.on_click_logout())
        settings_label.bind("<Button-1>", lambda e: self.on_click_settings())

        for element in [logout_label, settings_label]:
            element.bind("<Enter>", lambda e: self.main_window.config(cursor="hand2"))
            element.bind("<Leave>", lambda e: self.main_window.config(cursor=""))

    def setting_features(self):
        """Show password settings and delete account options. Update visibility flag."""
        # Destroy existing settings frame if any
        if self.settings_frame_features and self.settings_frame_features.winfo_exists():
            self.settings_frame_features.destroy()

        self.settings_frame_features = ctk.CTkFrame(
            self.main_window,
            corner_radius=26,
            width=339,
            height=340,
            fg_color="#CFF6CD",
            bg_color="#9FD39C"
        )
        self.settings_frame_features.place(x=615, y=80)
        self.settings_frame_features.lift()
        self.settings_visible = True

        self.images['image_5'] = self.load_image("image_5.png", (30, 30))
        arrow_image = ctk.CTkLabel(self.settings_frame_features, text="", image=self.images['image_5'])
        arrow_image.place(x=20, y=20)

        self.images['image_4'] = self.load_image("image_4.png", (50, 50))
        password_settings_image = ctk.CTkLabel(self.settings_frame_features, text="", image=self.images['image_4'])
        password_settings_image.place(x=20, y=100)

        password_settings_label = ctk.CTkLabel(self.settings_frame_features, text="Password Settings", font=("Poppins", 16 * -1, "bold"))
        password_settings_label.place(x=88, y=110)

        self.images['image_3'] = self.load_image("image_3.png", (50, 50))
        delete_account_image = ctk.CTkLabel(self.settings_frame_features, text="", image=self.images['image_3'])
        delete_account_image.place(x=20, y=190)

        delete_account_label = ctk.CTkLabel(self.settings_frame_features, text="Delete Account", font=("Poppins", 16 * -1, "bold"))
        delete_account_label.place(x=88, y=200)

        # Bind events
        password_settings_label.bind("<Button-1>", lambda e: self.on_click_password_settings())
        delete_account_label.bind("<Button-1>", lambda e: self.on_click_delete_account())
        arrow_image.bind("<Button-1>", lambda e: self.on_click_back())

        for element in [password_settings_label, delete_account_label, arrow_image]:
            element.bind("<Enter>", lambda e: self.main_window.config(cursor="hand2"))
            element.bind("<Leave>", lambda e: self.main_window.config(cursor=""))

    def hide_settings(self):
        """Hide and destroy any visible settings frame and update flag."""
        if self.settings_frame_features and self.settings_frame_features.winfo_exists():
            self.settings_frame_features.place_forget()
            self.settings_frame_features.destroy()
            self.settings_frame_features = None
        self.settings_visible = False

    def lift_settings(self):
        if self.settings_frame_features and self.settings_frame_features.winfo_exists():
            self.settings_frame_features.lift()

    def load_image(self, filename, size):
        try:
            image_path = ASSETS_PATH / filename
            pil_image = Image.open(image_path)
            return ctk.CTkImage(light_image=pil_image, size=size)
        except Exception as e:
            print(f"Error loading image {filename}: {e}")
            return None

    def on_click_logout(self):
        print("Logging out...")
        exit()

    def on_click_settings(self):
        self.setting_features()

    def on_click_password_settings(self):
        print("Password settings clicked")  # Add your logic here

    def on_click_delete_account(self):
        print("Delete account clicked")  # Add your logic here

    def on_click_back(self):
        self.show_settings()
































#     #    # my_image = ctk.CTkImage(light_image=Image.open(str(ASSETS_PATH / "image_7.png")), size =(262,337))

#     #     # mylabel = ctk.CTkLabel(self.main_window, text="", image=my_image,corner_radius=26)
#     #     # mylabel.place(x=660, y=80)
        

#     #     my_image = ctk.CTkImage(light_image=Image.open(ASSETS_PATH / "image_7.png"), size=(262,337))

#     #     image_label = ctk.CTkLabel(self.main_window, text="", Image=my_image)
#     #     image_label.pack(pady=10)

#     #     # self.notif_frame = ctk.CTkScrollableFrame(self.main_window, 
#     #     #                                         corner_radius=26,
#     #     #                                         width=262, 
#     #     #                                         height=337, 
#     #     #                                         fg_color="#CFF6CD",
#     #     #                                         bg_color="#9FD39C")
#     #     # self.notif_frame.place(x=655, y=80)


#     #     # # Generate multiple buttons inside the frame
#     #     # for x in range(10):
#     #     #     ctk.CTkButton(self.notif_frame, text=f"Button {x+1}").pack(pady=10)

#     #     self.notif_frame.place(x=475, y=-18)