from pathlib import Path
from tkinter import *
import customtkinter as ctk

ASSETS_PATH = Path(__file__).parent / "assets_transaction_categories"

class Transaction_Tab:
    def __init__(self, main_window):
        self.main_window = main_window
        self.images = {}
        self.open_analysis_new_window()

    def open_analysis_new_window(self):
        # Create a frame for the analysis tab
        self.frame = Frame(self.main_window, bg="#F4F4F4")
        self.frame.place(x=0, y=0, width=822, height=492)

        # Create a background canvas inside the frame
        self.frame_canvas = Canvas(
            self.frame,
            bg="#F4F4F4",
            height=492,  # Match the frame height
            width=822,   # Match the frame width
            bd=0,
            highlightthickness=0,
            relief="ridge"
        )
        self.frame_canvas.place(x=0, y=0)  # Correctly place the canvas

        # Load and place images
        self.load_rectangle()

    def load_rectangle(self):

        self.Transaction_Frame = ctk.CTkFrame(
            self.frame,
            corner_radius=26,
            width=778,
            height=414,
            fg_color="#9FD39C",
            bg_color="#F4F4F4"
        )
        self.Transaction_Frame.place(x=20, y=40)

        Transaction_label = ctk.CTkLabel(self.Transaction_Frame, text="Transaction", font=("Poppins", 20 * -1, "bold"))
        Transaction_label.place(x=35, y=20)