from pathlib import Path
from tkinter import *
import customtkinter as ctk
from PIL import Image
import Notification, Settings, Analysis, Transaction, Categories

ASSETS_PATH = Path(__file__).parent / "assets_Home"

class Home:
    def __init__(self, main_window):
        self.main_window = main_window
        self.main_window.title("Budget Tracker")

        # Set window size
        window_width = 1000
        window_height = 600

        # Get screen width and height
        screen_width = self.main_window.winfo_screenwidth()
        screen_height = self.main_window.winfo_screenheight()

        # Calculate position x, y to center the window
        center_x = int((screen_width / 2) - (window_width / 2))
        center_y = int((screen_height / 2) - (window_height / 2))

        self.main_window.geometry(f"{window_width}x{window_height}+{center_x}+{center_y}")
        self.main_window.configure(bg="#FFFFFF")
        self.main_window.resizable(False, False)

        self.images = {}
        self.current_tab = None
        self.interactive_ID = []
        self.home_frame = None
        self.current_tab_frame = None

        self.notification_handler = Notification.NotificationHandler(self.main_window)
        self.settings_handler = Settings.SettingsHandler(self.main_window)

        self.open_home_new_window()
    
    def open_home_new_window(self):
        self.canvas = Canvas(
            self.main_window,
            bg="#F4F4F4",
            height=600,
            width=500,
            bd=0,
            highlightthickness=0,
            relief="ridge"
        )
        self.canvas.pack(fill="both", expand=True)

        self.canvas.create_rectangle(0.0, 0.0, 179.0, 600.0, fill="#D7E6C5", outline="")
        self.canvas.create_rectangle(179.0, 0.0, 1000.0, 112.0, fill="#D7E6C5", outline="")
        self.canvas.create_rectangle(179.0, 110.0, 1001.0, 598.0, fill="#F4F4F4", outline="")

        self.create_home_frame()
        self.create_texts()
        self.load_images_rectangle()
        self.create_buttons()
        self.create_interactive_elements()

    def create_home_frame(self):
        self.home_frame = Frame(self.main_window, bg="#F4F4F4")
        self.home_frame.place(x=179, y=110, width=822, height=492)

        self.bg_canvas = Canvas(
            self.home_frame,
            bg="#F4F4F4",
            height=492,
            width=822,
            bd=0,
            highlightthickness=0,
            relief="ridge"
        )
        self.bg_canvas.place(x=0, y=0)

    def create_texts(self):
        self.bg_canvas.create_text(45, 30, anchor="nw", text="Analysis", fill="#052224", font=("Poppins", 20 * -1, "bold"))
        self.bg_canvas.create_text(595.0, 30.0, anchor="nw", text="Alerts", fill="#052224", font=("Poppins", 20 * -1, "bold"))
        self.bg_canvas.create_text(40.0, 250.0, anchor="nw", text="Transaction", fill="#052224", font=("Poppins", 20 * -1, "bold"))
        self.canvas.create_text(31.0, 36.0, anchor="nw", text="Hi, Welcome Back", fill="#052224", font=("Poppins", 20 * -1, "bold"))
        self.canvas.create_text(31.0, 64.285713, anchor="nw", text="Good Morning", fill="#052224", font=("LeagueSpartan", 14 * -1, "normal"))

    def load_images_rectangle(self):
        # Load the image for the top bar
        image_files = ["image_4.png"]
        image_positions = [(895.0, 46.0)]

        for img_file, pos in zip(image_files, image_positions):
            self.images[img_file] = PhotoImage(file=ASSETS_PATH / img_file)
            self.canvas.create_image(pos[0], pos[1], image=self.images[img_file])

        for img_file, pos in zip(image_files, image_positions):
            self.images[img_file] = PhotoImage(file=ASSETS_PATH / img_file)
            self.canvas.create_image(pos[0], pos[1], image=self.images[img_file])

        # Create Analysis Frame
        self.Analysis_Frame = ctk.CTkFrame(
            self.home_frame,
            corner_radius=26,
            width=537,
            height=168,
            fg_color="#9FD39C",
            bg_color="#F4F4F4"
        )
        self.Analysis_Frame.place(x=30, y=60)

        # Create Transaction Frame
        self.Transaction_Frame = ctk.CTkFrame(
            self.home_frame,
            corner_radius=26,
            width=537,
            height=168,
            fg_color="#9FD39C",
            bg_color="#F4F4F4"
        )
        self.Transaction_Frame.place(x=34, y=280)

        # Create Alerts Frame
        self.Alerts_Frame = ctk.CTkFrame(
            self.home_frame,
            corner_radius=26,
            width=192,
            height=392,
            fg_color="#9FD39C",
            bg_color="#F4F4F4"
        )
        self.Alerts_Frame.place(x=590, y=60)


    def create_buttons(self):
        button_files = ["button_1.png", "button_2.png", "button_3.png", "button_4.png"]
        button_commands = [self.on_click_home, self.on_click_analysis, self.on_click_transaction, self.on_click_categories]
        button_positions = [(8.0, 160.0), (5.0, 219.0), (7.0, 282.0), (7.0, 350.0)]

        for img_file, command, pos in zip(button_files, button_commands, button_positions):
            button_image = PhotoImage(file=ASSETS_PATH / img_file)
            button = Button(
                image=button_image,
                borderwidth=0,
                highlightthickness=0,
                activebackground="#D7E6C5",
                activeforeground="#9FD39C",
                command=command,
                relief="flat"
            )
            button.place(x=pos[0], y=pos[1], width=162.0, height=66.0)
            self.images[img_file] = button_image

    def create_interactive_elements(self):
        self.images["image_5"] = PhotoImage(file=ASSETS_PATH / "image_5.png")
        notification = self.canvas.create_image(866.0, 46.0, image=self.images["image_5"])

        self.images["image_6"] = PhotoImage(file=ASSETS_PATH / "image_6.png")
        settings = self.canvas.create_image(921.0, 46.0, image=self.images["image_6"])

        self.canvas.tag_bind(notification, "<Button-1>", lambda e: self.on_click_notification())
        self.canvas.tag_bind(settings, "<Button-1>", lambda e: self.on_click_settings())

        for element in [notification, settings]:
            self.canvas.tag_bind(element, "<Enter>", lambda e: self.canvas.config(cursor="hand2"))
            self.canvas.tag_bind(element, "<Leave>", lambda e: self.canvas.config(cursor=""))

    def clear_all_content(self):
        if self.home_frame and self.home_frame.winfo_exists():
            self.home_frame.place_forget()

        if self.current_tab_frame and self.current_tab_frame.winfo_exists():
            self.current_tab_frame.destroy()
            self.current_tab_frame = None

        if self.current_tab:
            if hasattr(self.current_tab, 'cleanup'):
                self.current_tab.cleanup()
            self.current_tab = None

        # Ensure notification and settings are lifted correctly
        self.settings_handler.lift_settings()
        self.notification_handler.lift_notification()
        

    def show_home(self):
        self.clear_all_content()  # Clear any existing content
        if self.home_frame and self.home_frame.winfo_exists():
            self.home_frame.place(x=179, y=110, width=822, height=492)
        else:
            self.create_home_frame()
            self.create_texts()
            self.load_images_rectangle()


    def show_other_tab(self, tab_class):
        self.clear_all_content()
        self.current_tab_frame = Frame(self.main_window, bg="#F4F4F4")
        self.current_tab_frame.place(x=179, y=110, width=822, height=492)
        self.current_tab = tab_class(self.current_tab_frame)

        self.settings_handler.lift_settings()
        self.notification_handler.lift_notification()
        
    def on_click_home(self):
        self.show_home()

    def on_click_analysis(self):
        self.show_other_tab(Analysis.Analysis_Tab)

    def on_click_transaction(self):
        self.show_other_tab(Transaction.Transaction_Tab)

    def on_click_categories(self):
        self.show_other_tab(Categories.Categories_Tab)

    def on_click_notification(self):
        """Handle notification click action."""
        # Hide settings if visible
        if self.settings_handler.settings_visible:
            self.settings_handler.hide_settings()
        
        # Toggle notification
        self.notification_handler.notification()

    def on_click_settings(self):
        """Handle settings click action."""
        # Hide notification if visible
        if self.notification_handler.notif_visible:
            self.notification_handler.hide_notification()
        
        # Show settings
        self.settings_handler.settings()

if __name__ == "__main__":
    main_window = Tk()
    system = Home(main_window)
    main_window.mainloop()
