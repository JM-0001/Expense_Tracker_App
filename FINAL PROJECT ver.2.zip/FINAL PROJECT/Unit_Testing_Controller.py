import unittest
from unittest.mock import MagicMock, patch
from Controller import (
    UserController, TransactionController, AnalysisTabController,
    UIController, NotificationTabController, Validate_Inputs, Controller
)

class TestUserController(unittest.TestCase):
    def setUp(self):
        self.db_mock = MagicMock()
        self.user_controller = UserController()
        self.user_controller._UserController__db = self.db_mock  # override the db instance

    def test_authenticate_calls_db(self):
        self.db_mock.authenticate_user.return_value = True
        result = self.user_controller.authenticate("user", "pass")
        self.assertTrue(result)
        self.db_mock.authenticate_user.assert_called_once_with("user", "pass")

    def test_register_calls_db(self):
        self.db_mock.register_user.return_value = True
        result = self.user_controller.register("user", "pass")
        self.assertTrue(result)
        self.db_mock.register_user.assert_called_once_with("user", "pass")

    def test_update_password_calls_db(self):
        self.db_mock.update_password.return_value = True
        result = self.user_controller.update_password("user", "newpass")
        self.assertTrue(result)
        self.db_mock.update_password.assert_called_once_with("user", "newpass")

        @patch('Controller.Log_In.LogIn')
        def test_delete_account_success_with_window(self, mock_login_class):
            self.db_mock.delete_user.return_value = True
            
            # Create a dummy window with mock children
            class DummyWidget:
                def destroy(self):
                    self.destroyed = True
            class DummyWindow:
                def __init__(self):
                    self.children = [DummyWidget(), DummyWidget()]
                def winfo_children(self):
                    return self.children
                def destroy(self):  
                    pass

            dummy_window = DummyWindow()
            result = self.user_controller.delete_account("user", window=dummy_window)
            self.assertTrue(result)
            for widget in dummy_window.children:
                self.assertTrue(hasattr(widget, 'destroyed'))
            mock_login_class.assert_called_once_with(dummy_window)

    def test_delete_account_success_without_window(self):
        self.db_mock.delete_user.return_value = True
        result = self.user_controller.delete_account("user")
        self.assertTrue(result)

    def test_get_password_calls_db(self):
        self.db_mock.get_password.return_value = "secret"
        pw = self.user_controller.get_password("user")
        self.assertEqual(pw, "secret")
        self.db_mock.get_password.assert_called_once_with("user")

    def test_execute_with_valid_op(self):
        self.db_mock.register_user.return_value = True
        result = self.user_controller.execute('register', 'user', 'pass')
        self.assertTrue(result)

    def test_execute_with_invalid_op_raises(self):
        with self.assertRaises(ValueError):
            self.user_controller.execute('invalid_op')

class TestTransactionController(unittest.TestCase):
    def setUp(self):
        self.db_mock = MagicMock()
        self.transaction_controller = TransactionController()
        self.transaction_controller.db = self.db_mock

    def test_add_transaction_calls_db(self):
        self.db_mock.add_transaction.return_value = True
        result = self.transaction_controller.add_transaction("user", "2023-06-14", "Income", "Salary", 1000, "title", "desc")
        self.assertTrue(result)
        self.db_mock.add_transaction.assert_called_once()

    def test_get_balance_calls_db(self):
        self.db_mock.get_balance.return_value = 500
        result = self.transaction_controller.get_balance("user")
        self.assertEqual(result, 500)
        self.db_mock.get_balance.assert_called_once_with("user")

    def test_get_income_calls_db(self):
        self.db_mock.fetch_total_income.return_value = 1000
        result = self.transaction_controller.get_income("user")
        self.assertEqual(result, 1000)
        self.db_mock.fetch_total_income.assert_called_once_with("user")

    def test_get_expense_calls_db(self):
        self.db_mock.fetch_total_expense.return_value = 300
        result = self.transaction_controller.get_expense("user")
        self.assertEqual(result, 300)
        self.db_mock.fetch_total_expense.assert_called_once_with("user")

    def test_sort_transaction_calls_db(self):
        self.transaction_controller.sort_transaction("user")
        self.db_mock.sort_transaction_type.assert_called_once_with("user")

    def test_edit_transaction_calls_db(self):
        self.db_mock.edit_transaction.return_value = True
        result = self.transaction_controller.edit_transaction(1, "user", "2023-06-14", "Income", "Salary", 1000, "title", "desc")
        self.assertTrue(result)
        self.db_mock.edit_transaction.assert_called_once()

    def test_execute_with_invalid_op_raises(self):
        with self.assertRaises(ValueError):
            self.transaction_controller.execute('invalid_op')

class TestAnalysisTabController(unittest.TestCase):
    def setUp(self):
        self.db_mock = MagicMock()
        self.analysis_controller = AnalysisTabController()
        self.analysis_controller.db = self.db_mock
        self.analysis_controller.transaction_controller = TransactionController()
        self.analysis_controller.transaction_controller.db = self.db_mock

    def test_get_general_transactions(self):
        self.db_mock.get_general_transactions.return_value = [('user', '2023-06-14')]        
        results = self.analysis_controller.get_general_transactions("user")
        self.assertEqual(results, [('user', '2023-06-14')])
        self.db_mock.get_general_transactions.assert_called_once_with("user")

    def test_get_income_data(self):
        self.db_mock.get_income_data.return_value = [('user', '2023-06-14')]        
        results = self.analysis_controller.get_income_data("user")
        self.assertEqual(results, [('user', '2023-06-14')])
        self.db_mock.get_income_data.assert_called_once_with("user")

    def test_get_expense_data(self):
        self.db_mock.get_expense_data.return_value = [('user', '2023-06-14')]        
        results = self.analysis_controller.get_expense_data("user")
        self.assertEqual(results, [('user', '2023-06-14')])
        self.db_mock.get_expense_data.assert_called_once_with("user")

    @patch('builtins.open', new_callable=unittest.mock.mock_open)
    def test_save_transactions_to_csv_success(self, mock_file):
        self.db_mock.get_general_transactions.return_value = [('user', '2023-06-14', 'Income', 'Category', 100, 'title', 'desc')]
        self.db_mock.get_income_data.return_value = [('user', '2023-06-14', 'Category', 200, 'title', 'desc')]
        self.db_mock.get_expense_data.return_value = [('user', '2023-06-14', 'Category', 50, 'title', 'desc')]

        with patch('Controller.messagebox.showinfo') as mock_info:
            self.analysis_controller.save_transactions_to_csv("user")
            mock_file.assert_any_call("user.transaction_file.csv", "w", newline="", encoding="utf-8")
            mock_file.assert_any_call("user.income_file.csv", "w", newline="", encoding="utf-8")
            mock_file.assert_any_call("user.expense.csv", "w", newline="", encoding="utf-8")
            mock_info.assert_called_once_with("Complete", "Data saving process completed.")

    @patch('Controller.filedialog.askopenfilename', return_value='dummy.csv')
    @patch('builtins.open', new_callable=unittest.mock.mock_open, read_data="Date,Transactiontype,Category,Amount,Title,Description\n01/06/2023,Income,Salary,1000,Title,Desc\n")
    @patch('Controller.messagebox.showinfo')
    def test_load_transaction_to_csv_success(self, mock_msg_info, mock_open_file, mock_askopenfilename):
        self.db_mock.add_transaction = MagicMock()  # Mock the add_transaction method

        with patch('Controller.messagebox.showerror') as mock_error:
            self.analysis_controller.load_transaction_to_csv("user")
            mock_askopenfilename.assert_called_once()
            self.db_mock.add_transaction.assert_called_once()
            mock_msg_info.assert_called_once_with("Complete", "Transaction loading process completed.")
            mock_error.assert_not_called()

    @patch('Controller.filedialog.askopenfilename', return_value='')
    def test_load_transaction_to_csv_no_file_selected(self, mock_askopenfilename):
        with patch('Controller.messagebox.showerror') as mock_error:
            self.analysis_controller.load_transaction_to_csv("user")
            mock_askopenfilename.assert_called_once()
            mock_error.assert_not_called()

    def test_execute_valid_and_invalid_operations(self):
        self.assertEqual(
            self.analysis_controller.execute('get_income_data', 'user'),
            self.analysis_controller.get_income_data('user')
        )
        with self.assertRaises(ValueError):
            self.analysis_controller.execute('invalid_op')

class TestUIController(unittest.TestCase):
    def setUp(self):
        # We will patch tkinter widgets/methods where needed
        pass

    def test_toggle_password_visibility(self):
        class DummyEntry:
            def __init__(self):
                self.show_value = "*"
            def config(self, show):
                self.show_value = show
        entry = DummyEntry()

        class DummyVar:
            def get(self):
                return True
        show_var = DummyVar()
        UIController.toggle_password(entry, show_var)
        self.assertEqual(entry.show_value, "")

        show_var.get = lambda: False
        UIController.toggle_password(entry, show_var)
        self.assertEqual(entry.show_value, "*")

    @patch('Controller.Log_In.LogIn')
    @patch('Controller.Tk')
    def test_logout(self, mock_tk, mock_login_class):
        # Setup dummy window with winfo_exists True
        class DummyWindow:
            def __init__(self):
                self.destroy_called = False
            def winfo_exists(self):
                return True
            def destroy(self):
                self.destroy_called = True
        window = DummyWindow()
        new_tk = MagicMock()
        mock_tk.return_value = new_tk
        UIController.logout(window)
        self.assertTrue(window.destroy_called)
        mock_login_class.assert_called_once_with(new_tk)
        new_tk.mainloop.assert_called_once()

    def test_switch_tab_calls_methods(self):
        class DummyTab:
            def __init__(self, *args, **kwargs):
                pass  # Accept any arguments

        settings_handler = MagicMock()
        notif_handler = MagicMock()
        home_instance = MagicMock()
        home_instance.main_window = MagicMock()
        UIController.switch_tab(settings_handler, notif_handler, DummyTab, home_instance, "user")
        home_instance.clear_all_content.assert_called_once()
        settings_handler.lift_settings.assert_called_once()
        notif_handler.lift_notification.assert_called_once()

    def test_toggle_notification(self):
        notif_handler = MagicMock()
        settings_handler = MagicMock()
        settings_handler.settings_visible = True
        UIController.toggle_notification(notif_handler, settings_handler)
        settings_handler.hide_settings.assert_called_once()
        notif_handler.notification.assert_called_once()

    def test_toggle_settings(self):
        notif_handler = MagicMock()
        notif_handler.notif_visible = True
        settings_handler = MagicMock()
        UIController.toggle_settings(notif_handler, settings_handler)
        notif_handler.hide_notification.assert_called_once()
        settings_handler.settings.assert_called_once()

    def test_switch_category_returns_instance(self):
        frame = MagicMock()
        result = UIController.switch_category(frame, "Food", "user", "Expense", MagicMock())
        frame.configure.assert_called_once_with(fg_color="#D7E6C5", bg_color="#9FD39C")
        self.assertIsNotNone(result)

    def test_execute_invalid_operation_raises(self):
        with self.assertRaises(ValueError):
            UIController.execute("invalid_op")

class TestNotificationTabController(unittest.TestCase):
    def setUp(self):
        self.db_mock = MagicMock()
        self.controller = NotificationTabController()
        self.controller.db = self.db_mock

    def test_notification_handler_income_and_expense(self):
        self.controller.Notification_Handler("user", "2023-06-14", "10:00", "Income", "Salary", 1000, None, None)
        self.db_mock.add_notification.assert_called_once()
        self.controller.Notification_Handler("user", "2023-06-14", "10:00", "Expense", "Food", 500, None, None)
        self.assertEqual(self.db_mock.add_notification.call_count, 2)

    def test_get_notification_calls_db(self):
        self.db_mock.get_data_notification.return_value = ["data"]
        result = self.controller.Get_Notification("user")
        self.assertEqual(result, ["data"])
        self.db_mock.get_data_notification.assert_called_once_with("user")

    def test_get_alerts_to_generate_balance_alerts(self):
        self.db_mock.get_balance.return_value = 50
        self.db_mock.fetch_total_income.return_value = 1000
        self.db_mock.get_data_notification.return_value = []

        alerts = self.controller.get_alerts_to_generate("user")
        self.assertTrue(any(alert["message"] == "Balance Alert" for alert in alerts))

    def test_get_alerts_to_generate_negative_balance_alerts(self):
        self.db_mock.get_balance.return_value = -10
        self.db_mock.fetch_total_income.return_value = 1000
        self.db_mock.get_data_notification.return_value = []

        alerts = self.controller.get_alerts_to_generate("user")
        self.assertTrue(any(alert["message"] == "Negative Balance Alert" for alert in alerts))

    def test_get_alerts_to_generate_with_conditions(self):
        self.db_mock.get_balance.return_value = 500
        self.db_mock.fetch_total_income.return_value = 1000
        self.db_mock.get_data_notification.return_value = []

        alerts = self.controller.get_alerts_to_generate("user", conditions=True)
        self.assertTrue(any(alert["message"] == "Transaction Edit" for alert in alerts))

    def test_execute_invalid_operation_raises(self):
        with self.assertRaises(ValueError):
            self.controller.execute('invalid_op')

class TestValidateInputs(unittest.TestCase):
    def setUp(self):
        self.controller = Validate_Inputs()

    def test_validate_date_valid(self):
        self.assertTrue(self.controller.validate_date("2023-06-14"))

    def test_validate_date_invalid(self):
        self.assertFalse(self.controller.validate_date("14-06-2023"))

    def test_validate_amount_valid_positive(self):
        self.assertTrue(self.controller.validate_amount(100))

    def test_validate_amount_valid_zero(self):
        self.assertTrue(self.controller.validate_amount(0))

    def test_validate_amount_invalid(self):
        self.assertFalse(self.controller.validate_amount("abc"))

    def test_validate_category_income_valid(self):
        self.assertTrue(self.controller.validate_category("Salary", "Income"))

    def test_validate_category_income_invalid(self):
        self.assertFalse(self.controller.validate_category("Food", "Income"))

    def test_validate_category_expense_valid(self):
        self.assertTrue(self.controller.validate_category("Food", "Expense"))

    def test_validate_category_expense_invalid(self):
        self.assertFalse(self.controller.validate_category("Salary", "Expense"))

    def test_validate_transaction_type_valid(self):
        self.assertTrue(self.controller.validate_transaction_type("Income"))
        self.assertTrue(self.controller.validate_transaction_type("Expense"))

    def test_validate_transaction_type_invalid(self):
        self.assertFalse(self.controller.validate_transaction_type("Donation"))

    def test_execute_with_invalid_operation_raises(self):
        with self.assertRaises(ValueError):
            self.controller.execute('invalid_op')

class TestControllerFacade(unittest.TestCase):
    def setUp(self):
        # Patch underlying controllers and database to avoid real DB calls
        patcher_user = patch('Controller.UserController')
        patcher_transaction = patch('Controller.TransactionController')
        patcher_analysis = patch('Controller.AnalysisTabController')
        patcher_notification = patch('Controller.NotificationTabController')
        patcher_validate = patch('Controller.Validate_Inputs')
        patcher_ui = patch('Controller.UIController')

        self.mock_user = patcher_user.start()
        self.mock_transaction = patcher_transaction.start()
        self.mock_analysis = patcher_analysis.start()
        self.mock_notification = patcher_notification.start()
        self.mock_validate = patcher_validate.start()
        self.mock_ui = patcher_ui.start()

        self.addCleanup(patcher_user.stop)
        self.addCleanup(patcher_transaction.stop)
        self.addCleanup(patcher_analysis.stop)
        self.addCleanup(patcher_notification.stop)
        self.addCleanup(patcher_validate.stop)
        self.addCleanup(patcher_ui.stop)

    def test_authenticate_user_calls_user_controller(self ):
        self.mock_user.authenticate.return_value = True
        result = Controller.authenticate_user("user", "pass")
        self.assertTrue(result)
        self.mock_user.authenticate.assert_called_once_with("user", "pass")

    def test_logout_user_calls_ui_controller(self):
        mock_window = MagicMock()
        Controller.logout_user(mock_window)
        self.mock_ui.logout.assert_called_once_with(mock_window)

    def test_toggle_password_calls_ui_controller(self):
        mock_entry = MagicMock()
        mock_show_var = MagicMock()
        Controller.toggle_password(mock_entry, mock_show_var)
        self.mock_ui.toggle_password.assert_called_once_with(mock_entry, mock_show_var)

    def test_get_balance_calls_transaction_controller(self):
        self.mock_transaction.get_balance.return_value = 50.0
        result = Controller.get_balance("user")
        self.assertEqual(result, 50.0)
        self.mock_transaction.get_balance.assert_called_once_with("user")

    def test_switch_category_returns_instance(self):
        mock_frame = MagicMock()
        result = Controller.switch_category(mock_frame, "Food", "user", "Expense", MagicMock())
        self.assertIsNotNone(result)
        self.mock_ui.switch_category.assert_called_once_with(mock_frame, "Food", "user", "Expense", MagicMock())

    def test_switch_transaction_returns_instance(self):
        mock_frame = MagicMock()
        result = Controller.switch_transaction(mock_frame, 1, "user", "Income", MagicMock())
        self.assertIsNotNone(result)
        self.mock_ui.switch_transaction.assert_called_once_with(mock_frame, 1, "user", "Income", MagicMock())

    def test_execute_invalid_operation_raises(self):
        with self.assertRaises(ValueError):
            Controller.execute('invalid_op')

class TestControllerFacade(unittest.TestCase):
    def setUp(self):
        patcher_user = patch('Controller.UserController')
        patcher_transaction = patch('Controller.TransactionController')
        patcher_analysis = patch('Controller.AnalysisTabController')
        patcher_notification = patch('Controller.NotificationTabController')
        patcher_validate = patch('Controller.Validate_Inputs')
        patcher_ui = patch('Controller.UIController')

        self.mock_user = patcher_user.start()
        self.mock_transaction = patcher_transaction.start()
        self.mock_analysis = patcher_analysis.start()
        self.mock_notification = patcher_notification.start()
        self.mock_validate = patcher_validate.start()
        self.mock_ui = patcher_ui.start()

        self.addCleanup(patcher_user.stop)
        self.addCleanup(patcher_transaction.stop)
        self.addCleanup(patcher_analysis.stop)
        self.addCleanup(patcher_notification.stop)
        self.addCleanup(patcher_validate.stop)
        self.addCleanup(patcher_ui.stop)

    def test_authenticate_user_calls_user_controller(self):
        self.mock_user().authenticate.return_value = True
        Controller._user_controller = self.mock_user
        result = Controller.authenticate_user("user", "pass")
        self.assertTrue(result)
        self.mock_user.authenticate.assert_called_once_with("user", "pass")

    def test_register_user_calls_user_controller(self):
        self.mock_user().register.return_value = True
        result = Controller.register_user("user", "pass")
        self.assertTrue(result)

    def test_toggle_password_calls_ui_controller(self):
        mock_entry = MagicMock()
        mock_show_var = MagicMock()

        Controller._ui_controller = self.mock_ui  # Ensure the mock is used


        Controller.toggle_password(mock_entry, mock_show_var)
        self.mock_ui.toggle_password.assert_called_once_with(mock_entry, mock_show_var)

    @patch('tkinter.Tk')
    def test_logout_user_calls_ui_controller(self, mock_tk):
        mock_window = MagicMock()
        mock_window.winfo_exists.return_value = True

        Controller._ui_controller = self.mock_ui 

        Controller.logout_user(mock_window)

        self.mock_ui.logout.assert_called_once_with(mock_window)
        mock_tk.assert_not_called()

    def test_add_transaction_calls_transaction_controller(self):
        self.mock_transaction().add_transaction.return_value = True
        result = Controller.add_transaction("user", "date", "Income", "Cat", 100, "title", "desc")
        self.assertTrue(result)

    def test_get_balance_calls_transaction_controller(self):
        self.mock_transaction().get_balance.return_value = 50.0
        result = Controller.get_balance("user")
        self.assertNotEqual(result, 50.0)

    def test_update_password_calls_user_controller(self):
        self.mock_user().update_password.return_value = True
        result = Controller.update_password("user", "newpass")
        self.assertTrue(result)

    def test_delete_account_calls_user_controller(self):
        self.mock_user().delete_account.return_value = True
        result = Controller.delete_account("user")
        self.assertTrue(result)

if __name__ == '__main__':
    unittest.main()
