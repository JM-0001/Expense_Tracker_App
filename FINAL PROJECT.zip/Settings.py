import customtkinter as ctk
from pathlib import Path
from PIL import Image
import Controller, Change_Password
from tkinter import messagebox

ASSETS_PATH = Path(__file__).parent / "assets_settings"

class SettingsHandler:
    def __init__(self, main_window, username):
        self.main_window = main_window
        self.username = username
        self.settings_frame_features = None
        self.settings_visible = False
        self.images = {}

    def is_visible(self):
        return self.settings_visible and self.settings_frame_features is not None \
               and self.settings_frame_features.winfo_exists()

    def settings(self):
        if self.is_visible():
            self.hide_settings()
        else:
            self.show_settings()

    def show_settings(self):
        if self.settings_frame_features and self.settings_frame_features.winfo_exists():
            self.settings_frame_features.destroy()

        self.settings_frame_features = ctk.CTkFrame(
            self.main_window,
            corner_radius=26,
            width=340,
            height=340,
            fg_color="#CFF6CD",
            bg_color="#9FD39C"
        )
        self.settings_frame_features.place(x=861, y=93)
        self.settings_frame_features.lift()
        self.settings_visible = True

        # Load and place images with labels
        self.images['image_1'] = self.load_image("image_1.png", (70, 70))
        if self.images['image_1']:
            label_image_1 = ctk.CTkLabel(self.settings_frame_features, text="", image=self.images['image_1'])
            label_image_1.place(x=20, y=220)

        logout_label = ctk.CTkLabel(self.settings_frame_features, text="Logout", font=("Poppins", 16, "bold"))
        logout_label.place(x=104, y=240)

        self.images['image_2'] = self.load_image("image_2.png", (70, 70))
        if self.images['image_2']:
            label_image_2 = ctk.CTkLabel(self.settings_frame_features, text="", image=self.images['image_2'])
            label_image_2.place(x=20, y=130)

        settings_label = ctk.CTkLabel(self.settings_frame_features, text="Settings", font=("Poppins", 16, "bold"))
        settings_label.place(x=104, y=150)

        self.images['image_3'] = self.load_image("image_3.png", (50, 50))
        if self.images['image_3']:
            label_image_3 = ctk.CTkLabel(self.settings_frame_features, text="", image=self.images['image_3'])
            label_image_3.place(x=147, y=30)

        user_label = ctk.CTkLabel(self.settings_frame_features, text=self.username, font=("Poppins", 16, "bold"))
        user_label.place(relx=0.5, rely=0.3, anchor="center")

        # Bind events
        logout_label.bind("<Button-1>", lambda e: self.on_click_logout())
        settings_label.bind("<Button-1>", lambda e: self.on_click_settings())

        for element in [logout_label, settings_label]:
            element.bind("<Enter>", lambda e: self.settings_frame_features.configure(cursor="hand2"))
            element.bind("<Leave>", lambda e: self.settings_frame_features.configure(cursor=""))

    def setting_features(self):
        for widget in self.settings_frame_features.winfo_children():
            widget.destroy()

        self.images['image_5'] = self.load_image("image_5.png", (30, 30))
        if self.images['image_5']:
            arrow_image = ctk.CTkLabel(self.settings_frame_features, text="", image=self.images['image_5'])
            arrow_image.place(x=20, y=20)

        # Add settings title
        settings_title = ctk.CTkLabel(self.settings_frame_features, text="Settings", font=("Poppins", 18, "bold"))
        settings_title.place(x=130, y=20)

        # Add password settings option
        self.images['image_4'] = self.load_image("image_4.png", (50, 50))
        if self.images['image_4']:
            password_settings_image = ctk.CTkLabel(self.settings_frame_features, text="", image=self.images['image_4'])
            password_settings_image.place(x=20, y=100)

        password_settings_label = ctk.CTkLabel(self.settings_frame_features, text="Change Password", font=("Poppins", 16, "bold"))
        password_settings_label.place(x=88, y=115)

        # Add delete account option
        self.images['image_3'] = self.load_image("image_3.png", (50, 50))
        if self.images['image_3']:
            delete_account_image = ctk.CTkLabel(self.settings_frame_features, text="", image=self.images['image_3'])
            delete_account_image.place(x=20, y=190)

        delete_account_label = ctk.CTkLabel(self.settings_frame_features, text="Delete Account", font=("Poppins", 16, "bold"))
        delete_account_label.place(x=88, y=205)

        # Bind events
        password_settings_label.bind("<Button-1>", lambda e: self.on_click_change_password())
        delete_account_label.bind("<Button-1>", lambda e: self.on_click_delete_account())
        arrow_image.bind("<Button-1>", lambda e: self.on_click_back())

        # Set cursor style for interactive elements
        for element in [password_settings_label, delete_account_label, arrow_image]:
            element.bind("<Enter>", lambda e: self.settings_frame_features.configure(cursor="hand2"))
            element.bind("<Leave>", lambda e: self.settings_frame_features.configure(cursor=""))

    def hide_settings(self):
        """Hide and destroy any visible settings frame and update flag."""
        if self.settings_frame_features and self.settings_frame_features.winfo_exists():
            self.settings_frame_features.place_forget()
            self.settings_frame_features.destroy()
            self.settings_frame_features = None
        self.settings_visible = False

    def lift_settings(self):
        if self.settings_frame_features and self.settings_frame_features.winfo_exists():
            self.settings_frame_features.lift()

    def load_image(self, filename, size):
        image_path = ASSETS_PATH / filename
        if not image_path.exists():
            print(f"Image file not found: {image_path}")
            return None
        pil_image = Image.open(image_path)
        return ctk.CTkImage(light_image=pil_image, size=size)

    def on_click_logout(self):
        Controller.Controller.logout_user(self.main_window)

    def on_click_settings(self):
        self.setting_features()

    def on_click_delete_account(self):
        confirm = messagebox.askyesno("Confirm", "Are you sure you want to delete your account?\nThis action cannot be undone.")
        if confirm:
            Controller.Controller.delete_account(self.username, self.main_window)

    def on_click_change_password(self):
        Change_Password.ChangePassword(self.settings_frame_features, self.username, self)

    def on_click_back(self):
        self.show_settings()
































#     #    # my_image = ctk.CTkImage(light_image=Image.open(str(ASSETS_PATH / "image_7.png")), size =(262,337))

#     #     # mylabel = ctk.CTkLabel(self.main_window, text="", image=my_image,corner_radius=26)
#     #     # mylabel.place(x=660, y=80)
        

#     #     my_image = ctk.CTkImage(light_image=Image.open(ASSETS_PATH / "image_7.png"), size=(262,337))

#     #     image_label = ctk.CTkLabel(self.main_window, text="", Image=my_image)
#     #     image_label.pack(pady=10)

#     #     # self.notif_frame = ctk.CTkScrollableFrame(self.main_window, 
#     #     #                                         corner_radius=26,
#     #     #                                         width=262, 
#     #     #                                         height=337, 
#     #     #                                         fg_color="#CFF6CD",
#     #     #                                         bg_color="#9FD39C")
#     #     # self.notif_frame.place(x=655, y=80)


#     #     # # Generate multiple buttons inside the frame
#     #     # for x in range(10):
#     #     #     ctk.CTkButton(self.notif_frame, text=f"Button {x+1}").pack(pady=10)

#     #     self.notif_frame.place(x=475, y=-18)