# from pathlib import Path
# from tkinter import *
# from PIL import Image, ImageTk
# import Category_Entry, Controller

# ASSETS_PATH = Path(__file__).parent / "assets_categories_income"


# class Category_Incomes:
#     def __init__(self, Income_Expense_Frame, username, categories_tab_instance):
#         self.Income_Expense_Frame = Income_Expense_Frame
#         self.username = username
#         self.categories_tab_instance = categories_tab_instance
#         self.images = {}
#         self.open_income_widgets()

#     def load_image(self, image_name, size):
#         img = Image.open(ASSETS_PATH / image_name)
#         return ImageTk.PhotoImage(img)

#     def clear_all_content(self):
#         for widget in self.Income_Expense_Frame.winfo_children():
#             widget.destroy()

#     def on_button_click(self, category):
#         self.clear_all_content()
#         Controller.UIController.switch_category(self.Income_Expense_Frame, category, self.username, "Income", self.categories_tab_instance)

#         self.categories_tab_instance.update_balance_labels()

#     def open_income_widgets(self):
#         self.images['salary'] = self.load_image("salary.png", (95,117))
#         salary = Button(self.Income_Expense_Frame, image=self.images['salary'], command=lambda: self.on_button_click("Salary"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         salary.place(x=44, y=37)

#         self.images['investment'] = self.load_image("investment.png", (96,117))
#         investment = Button(self.Income_Expense_Frame, image=self.images['investment'], command=lambda: self.on_button_click("Investment"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         investment.place(x=176, y=37)

#         self.images['bonus'] = self.load_image("bonus.png", (95,117))
#         bonus = Button(self.Income_Expense_Frame, image=self.images['bonus'], command=lambda: self.on_button_click("Bonus"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         bonus.place(x=307, y=37)

#         self.images['receipt'] = self.load_image("receipt.png", (95,117))
#         receipt = Button(self.Income_Expense_Frame, image=self.images['receipt'], command=lambda: self.on_button_click("Receipt"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         receipt.place(x=44, y=194)

#         self.images['dividend'] = self.load_image("dividend.png", (95,117))
#         dividend = Button(self.Income_Expense_Frame, image=self.images['dividend'], command=lambda: self.on_button_click("Dividend"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         dividend.place(x=176, y=194)

#         self.images['gifts'] = self.load_image("gifts.png", (95,120))
#         gifts = Button(self.Income_Expense_Frame, image=self.images['gifts'], command=lambda: self.on_button_click("Gifts"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         gifts.place(x=307, y=194)

#         self.images['borrowing'] = self.load_image("borrowing.png", (95,117))
#         borrowing = Button(self.Income_Expense_Frame, image=self.images['borrowing'], command=lambda: self.on_button_click("Borrowing"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         borrowing.place(x=44, y=345)

#         self.images['allowance'] = self.load_image("allowance.png", (95,117))
#         allowance = Button(self.Income_Expense_Frame, image=self.images['allowance'], command=lambda: self.on_button_click("Allowance"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         allowance.place(x=176, y=345)

#         self.images['more'] = self.load_image("more.png", (95,112))
#         more = Button(self.Income_Expense_Frame, image=self.images['more'], command=lambda: self.on_button_click("More"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         more.place(x=307, y=345)




from pathlib import Path
from tkinter import Button
from PIL import Image, ImageTk
import Controller
from abc import ABC, abstractmethod

ASSETS_PATH = Path(__file__).parent / "assets_categories_income"

class BaseCategoryView(ABC):
    """Abstract base class for category views (Abstraction)"""
    def __init__(self, parent_frame, username, tab_instance):
        self.parent_frame = parent_frame
        self.username = username
        self.tab_instance = tab_instance
        self.images = {}
        self._load_assets()
        self._setup_view()

    @abstractmethod
    def _load_assets(self):
        """Load required images/assets"""
        pass

    @abstractmethod
    def _setup_view(self):
        """Setup the category view"""
        pass

    def clear_all_content(self):
        """Clear all widgets from parent frame"""
        for widget in self.parent_frame.winfo_children():
            widget.destroy()

class IncomeCategoryView(BaseCategoryView):
    """Income category view implementation (Inheritance)"""
    def _load_assets(self):
        """Load all income category images (Encapsulation)"""
        self.category_assets = [
            ("salary", "Salary"), ("investment", "Investment"), 
            ("bonus", "Bonus"), ("receipt", "Receipt"),
            ("dividend", "Dividend"), ("gifts", "Gifts"),
            ("borrowing", "Borrowing"), ("allowance", "Allowance"),
            ("more", "More")
        ]
        
        for img_name, _ in self.category_assets:
            img_path = ASSETS_PATH / f"{img_name}.png"
            img = Image.open(img_path)
            self.images[img_name] = ImageTk.PhotoImage(img)

    def _setup_view(self):
        """Create the income category buttons grid"""
        positions = [
            (44, 37), (176, 37), (307, 37),  # Row 1
            (44, 194), (176, 194), (307, 194), # Row 2
            (44, 345), (176, 345), (307, 345)  # Row 3
        ]
        
        for (img_name, category), (x, y) in zip(self.category_assets, positions):
            self._create_category_button(img_name, category, x, y)

    def _create_category_button(self, img_name, category, x, y):
        """Create a category button (Encapsulation)"""
        btn = Button(
            self.parent_frame,
            image=self.images[img_name],
            command=lambda c=category: self._on_category_select(c),
            borderwidth=0,
            activebackground="#DFF7E2",
            bg="#DFF7E2"
        )
        btn.place(x=x, y=y)

    def _on_category_select(self, category):
        """Handle category selection (Polymorphism)"""
        self.clear_all_content()
        Controller.UIController.switch_category(
            self.parent_frame, 
            category, 
            self.username, 
            "Income", 
            self.tab_instance
        )
        self.tab_instance.update_balance_labels()






















