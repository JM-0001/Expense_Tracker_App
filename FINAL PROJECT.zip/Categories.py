# from pathlib import Path
# from tkinter import *
# import customtkinter as ctk
# import Controller, Category_Income, Category_Expense
# from PIL import Image
# from abc import ABC, abstractmethod

# ASSETS_PATH = Path(__file__).parent / "assets_categories_income"

# class BaseCategories(ABC):
#     pass

# class Categories_Tab:
#     def __init__(self, main_window, username):
#         self.main_window = main_window
#         self.username = username
#         self.images = {}
#         self.open_categories_new_window()

#     def open_categories_new_window(self):
#         self.frame = Frame(self.main_window, bg="#F4F4F4")
#         self.frame.place(x=0, y=0, width=1051, height=621)

#         self.frame_canvas = Canvas(self.frame, bg="#F4F4F4", height=621, width=1051, bd=0, highlightthickness=0, relief="ridge")
#         self.frame_canvas.place(x=0, y=0)

#         self.load_rectangle()

#     def load_image(self, image_name, size):
#         img = Image.open(ASSETS_PATH / image_name)
#         return ctk.CTkImage(img, size=size)

#     def update_balance_labels(self):
#         """Refresh total balance, income, and expense labels dynamically."""
#         self.balance_label.configure(text=Controller.Controller.get_balance(self.username))
#         self.income_image.configure(text=Controller.Controller.get_income(self.username))
#         self.expense_image.configure(text=Controller.Controller.get_expense(self.username))

#     def on_click_income_categories(self):
#         """Switch to Income widgets"""
#         self.clear_all_content()
#         self.income_label.configure(bg_color="#9FD39C")
#         self.expense_label.configure(bg_color="#F1FFF3")
#         self.Income_Expense_Frame.configure(fg_color="#DFF7E2")
#         self.selected_frame.place(x=41, y=6)
        
#         Category_Income.Category_Incomes(self.Income_Expense_Frame, self.username, self)
        
#     def on_click_expense_categories(self):
#         """Switch to Expense widgets"""
#         self.clear_all_content()
#         self.expense_label.configure(bg_color="#9FD39C")
#         self.income_label.configure(bg_color="#F1FFF3")
#         self.Income_Expense_Frame.configure(fg_color="#DFF7E2")
#         self.selected_frame.place(x=265, y=6)

#         Category_Expense.Category_Expenses(self.Income_Expense_Frame, self.username, self)

#     def clear_all_content(self):
#         for widget in self.Income_Expense_Frame.winfo_children():
#             widget.destroy()

#     def load_rectangle(self):
#         self.Categories_Frame = ctk.CTkFrame(self.frame, corner_radius=26, width=1002, height=565, fg_color="#9FD39C", bg_color="#F4F4F4")
#         self.Categories_Frame.place(x=26, y=27)

#         Category_label = ctk.CTkLabel(self.Categories_Frame, text="Categories", font=("Poppins", 20 * -1, "bold"))
#         Category_label.place(x=27, y=20)

#         self.Balance_Frame = ctk.CTkFrame(self.Categories_Frame, corner_radius=14, width=430, height=90, fg_color="#F1FFF3")
#         self.Balance_Frame.place(x=57, y=130)

#         Total_balance_label = ctk.CTkLabel(self.Balance_Frame, text="Total Balance", font=("Inter Medium", 17 * -1))
#         Total_balance_label.place(relx=0.5, rely=0.28, anchor="center")

#         self.balance_label = ctk.CTkLabel(self.Balance_Frame, text=Controller.Controller.get_balance(self.username), font=("Arial Black", 26 * -1), anchor="center")
#         self.balance_label.place(relx=0.5, rely=0.6, anchor="center")

#         self.Income_Expense_Button_Frame = ctk.CTkFrame(self.Categories_Frame, corner_radius=14, width=430, height=50, fg_color="#F1FFF3")
#         self.Income_Expense_Button_Frame.place(x=57, y=261)

#         # This frame will move behind the selected option
#         self.selected_frame = ctk.CTkFrame(self.Income_Expense_Button_Frame, corner_radius=26, width=130, height=39, fg_color="#9FD39C")
#         self.selected_frame.place(x=41, y=5)

#         # Create clickable labels
#         self.income_label = ctk.CTkLabel(self.Income_Expense_Button_Frame, text="Income", font=("Poppins", 17, "normal"), anchor="n", bg_color="#9FD39C")
#         self.income_label.place(x=80, y=14)

#         self.expense_label = ctk.CTkLabel(self.Income_Expense_Button_Frame, text="Expense", font=("Poppins", 17, "normal"), anchor="n")
#         self.expense_label.place(x=300, y=14)

#         self.images['income_frame'] = self.load_image("income_frame.png", (198,95))
#         self.income_image = ctk.CTkLabel(self.Categories_Frame, text=Controller.Controller.get_income(self.username), image=self.images['income_frame'], font=("Poppins", 20 * -1, "bold"))
#         self.income_image.place(x=57, y=340)

#         self.images['expense_frame'] = self.load_image("expense_frame.png", (198,95))
#         self.expense_image = ctk.CTkLabel(self.Categories_Frame, text=Controller.Controller.get_expense(self.username), image=self.images['expense_frame'], font=("Poppins", 20 * -1, "bold"))
#         self.expense_image.place(x=289, y=340)

#         self.Line = ctk.CTkFrame(self.Categories_Frame, width=3, height=95.5, fg_color="#DFF7E2")
#         self.Line.place(x=272, y=335)

#         # Bind click events to the labels
#         self.income_label.bind("<Button-1>", lambda e: self.on_click_income_categories())
#         self.expense_label.bind("<Button-1>", lambda e: self.on_click_expense_categories())

#         # Bind hover effects
#         for element in [self.income_label, self.expense_label]:
#             element.bind("<Enter>", lambda e: self.main_window.config(cursor="hand2"))
#             element.bind("<Leave>", lambda e: self.main_window.config(cursor=""))

#         self.Income_Expense_Frame = ctk.CTkFrame(
#             self.Categories_Frame,
#             corner_radius=26,
#             width=440,
#             height=500,
#             fg_color="#DFF7E2",
#             bg_color="#9FD39C"
#         )
#         self.Income_Expense_Frame.place(x=535, y=33)

#         Category_Income.Category_Incomes(self.Income_Expense_Frame, self.username, self)







from pathlib import Path
import customtkinter as ctk
from PIL import Image, ImageTk
import Controller
import Category_Income
import Category_Expense

ASSETS_PATH = Path(__file__).parent / "assets_categories_income"

class CategoriesTab:
    def __init__(self, main_window, username):
        self.main_window = main_window
        self.username = username
        self.images = {}
        self.current_view = None
        
        # First create all frames
        self._create_main_container()
        self._create_balance_section()
        self._create_category_switcher()
        self._create_category_display_area()
        
        # Then load images and default view
        self._load_images()
        self._load_default_view()

    def _create_main_container(self):
        """Create the main frame container"""
        self.main_frame = ctk.CTkFrame(
            self.main_window,
            corner_radius=26,
            width=1002,
            height=565,
            fg_color="#9FD39C"
        )
        self.main_frame.place(x=26, y=27)

    def _load_images(self):
        """Load all required images"""
        # Load income/expense frames
        self.images['income_frame'] = self._load_ctk_image("income_frame.png", (198, 95))
        self.images['expense_frame'] = self._load_ctk_image("expense_frame.png", (198, 95))

    def _load_ctk_image(self, image_name, size):
        """Helper to load CTk compatible images"""
        img = Image.open(ASSETS_PATH / image_name)
        return ctk.CTkImage(img, size=size)

    def _create_balance_section(self):
        """Create the balance display section"""
        self.balance_frame = ctk.CTkFrame(
            self.main_frame,
            corner_radius=14,
            width=430,
            height=90,
            fg_color="#F1FFF3"
        )
        self.balance_frame.place(x=57, y=130)
        
        # Balance title
        ctk.CTkLabel(
            self.balance_frame, 
            text="Total Balance", 
            font=("Inter Medium", 17)
        ).place(relx=0.5, rely=0.28, anchor="center")
        
        # Balance value
        self.balance_value = ctk.CTkLabel(
            self.balance_frame,
            text=Controller.Controller.get_balance(self.username),
            font=("Arial Black", 26)
        )
        self.balance_value.place(relx=0.5, rely=0.6, anchor="center")

    def _create_category_switcher(self):
        """Create the income/expense toggle switcher"""
        self.switcher_frame = ctk.CTkFrame(
            self.main_frame,
            corner_radius=14,
            width=430,
            height=50,
            fg_color="#F1FFF3"
        )
        self.switcher_frame.place(x=57, y=261)

        # Selection indicator
        self.selected_frame = ctk.CTkFrame(
            self.switcher_frame,
            corner_radius=26,
            width=130,
            height=39,
            fg_color="#9FD39C"
        )
        self.selected_frame.place(x=41, y=8)

        # Income button
        self.income_label = ctk.CTkLabel(
            self.switcher_frame,
            text="Income",
            font=("Poppins", 17),
            bg_color="#9FD39C"
        )
        self.income_label.place(x=80, y=12)
        self.income_label.bind("<Button-1>", lambda e: self.show_income_view())
        
        # Expense button
        self.expense_label = ctk.CTkLabel(
            self.switcher_frame,
            text="Expense",
            font=("Poppins", 17)
        )
        self.expense_label.place(x=300, y=12)
        self.expense_label.bind("<Button-1>", lambda e: self.show_expense_view())

        # Set hover effects
        for label in [self.income_label, self.expense_label]:
            label.bind("<Enter>", lambda e: self.main_window.config(cursor="hand2"))
            label.bind("<Leave>", lambda e: self.main_window.config(cursor=""))

    def _create_category_display_area(self):
        self.Income_Expense_Frame = ctk.CTkFrame(
            self.main_frame,
            corner_radius=26,
            width=440,
            height=500,
            fg_color="#DFF7E2",
            bg_color="#9FD39C"
        )
        self.Income_Expense_Frame.place(x=535, y=33)

    def _load_default_view(self):
        """Load the default income view with images"""
        # Position selector for income
        self.selected_frame.place(x=41, y=5)
        
        # Create income/expense image displays
        self.income_image = ctk.CTkLabel(
            self.main_frame,
            text=Controller.Controller.get_income(self.username),
            image=self.images['income_frame'],
            font=("Poppins", 20, "bold"),
            compound="center"
        )
        self.income_image.place(x=57, y=340)

        self.expense_image = ctk.CTkLabel(
            self.main_frame,
            text=Controller.Controller.get_expense(self.username),
            image=self.images['expense_frame'],
            font=("Poppins", 20, "bold"),
            compound="center"
        )
        self.expense_image.place(x=289, y=340)

        # Separator line
        self.line = ctk.CTkFrame(
            self.main_frame,
            width=3,
            height=106.5,
            fg_color="#DFF7E2"
        )
        self.line.place(x=272, y=335)

        # Load default income view
        self._load_category_view("Income")

    def show_income_view(self):
        self._update_switcher_state(is_income=True)
        self._load_category_view("Income")

    def show_expense_view(self):
        self._update_switcher_state(is_income=False)
        self._load_category_view("Expense")

    def _update_switcher_state(self, is_income):
        x_pos = 41 if is_income else 265
        self.selected_frame.place(x=x_pos, y=5)
        self.income_label.configure(bg_color="#9FD39C" if is_income else "#F1FFF3")
        self.expense_label.configure(bg_color="#9FD39C" if not is_income else "#F1FFF3")
        self.Income_Expense_Frame.configure(fg_color="#DFF7E2")
        

    def _load_category_view(self, view_type):
        """Load the appropriate category view"""
        if self.current_view:
            self.current_view.clear_all_content()
        
        if view_type == "Income":
            self.current_view = Category_Income.IncomeCategoryView(
                self.Income_Expense_Frame,
                self.username,
                self
            )
        else:
            self.current_view = Category_Expense.ExpenseCategoryView(
                self.Income_Expense_Frame,
                self.username,
                self
            )

    def update_balance_labels(self):
        """Update all balance-related displays"""
        self.balance_value.configure(text=Controller.Controller.get_balance(self.username))
        self.income_image.configure(text=Controller.Controller.get_income(self.username))
        self.expense_image.configure(text=Controller.Controller.get_expense(self.username))












