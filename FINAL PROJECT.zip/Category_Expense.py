# from pathlib import Path
# from tkinter import *
# import customtkinter as ctk
# import Controller
# from PIL import Image, ImageTk
# import Category_Entry


# ASSETS_PATH = Path(__file__).parent / "assets_categories_expense"

# class Category_Expenses:
#     def __init__(self, Income_Expense_Frame, username, categories_tab_instance):
#         self.Income_Expense_Frame = Income_Expense_Frame
#         self.username = username
#         self.categories_tab_instance = categories_tab_instance
#         self.images = {}
#         self.open_expense_widgets()

#     def load_image(self, image_name, size):
#         img = Image.open(ASSETS_PATH / image_name)
#         return ImageTk.PhotoImage(img)

#     def clear_all_content(self):
#         for widget in self.Income_Expense_Frame.winfo_children():
#             widget.destroy()

#     def on_button_click(self, category):
#         self.clear_all_content()
#         Controller.UIController.switch_category(self.Income_Expense_Frame, category, self.username, "Expense", self.categories_tab_instance)

#         self.categories_tab_instance.update_balance_labels()

#     def open_expense_widgets(self):
#         self.images['food'] = self.load_image("food.png", (95,122))
#         food = Button(self.Income_Expense_Frame, image=self.images['food'], command=lambda: self.on_button_click("Food"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         food.place(x=45, y=36)

#         self.images['transport'] = self.load_image("transport.png", (121,123))
#         transport = Button(self.Income_Expense_Frame, image=self.images['transport'], command=lambda: self.on_button_click("Transport"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         transport.place(x=175, y=36)

#         self.images['medicine'] = self.load_image("medicine.png", (100,122))
#         medicine = Button(self.Income_Expense_Frame, image=self.images['medicine'], command=lambda: self.on_button_click("Medicine"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         medicine.place(x=302, y=36)

#         self.images['groceries'] = self.load_image("groceries.png", (106,123))
#         groceries = Button(self.Income_Expense_Frame, image=self.images['groceries'], command=lambda: self.on_button_click("Groceries"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         groceries.place(x=45, y=190)

#         self.images['rent'] = self.load_image("rent.png", (96,122))
#         rent = Button(self.Income_Expense_Frame, image=self.images['rent'], command=lambda: self.on_button_click("Rent"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         rent.place(x=175, y=190)

#         self.images['gifts'] = self.load_image("gifts.png", (95,122))
#         gifts = Button(self.Income_Expense_Frame, image=self.images['gifts'], command=lambda: self.on_button_click("Gifts"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         gifts.place(x=302, y=190)

#         self.images['savings'] = self.load_image("savings.png", (117,120))
#         savings = Button(self.Income_Expense_Frame, image=self.images['savings'], command=lambda: self.on_button_click("Savings"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         savings.place(x=45, y=343)

#         self.images['entertainment'] = self.load_image("entertainment.png", (138,121))
#         entertainment = Button(self.Income_Expense_Frame, image=self.images['entertainment'], command=lambda: self.on_button_click("Entertainment"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         entertainment.place(x=172, y=343)

#         self.images['more'] = self.load_image("more.png", (95,121))
#         more = Button(self.Income_Expense_Frame, image=self.images['more'], command=lambda: self.on_button_click("More"), borderwidth=0, activebackground="#DFF7E2", bg="#DFF7E2")
#         more.place(x=302, y=343)







from pathlib import Path
from tkinter import Button
from PIL import Image, ImageTk
import Controller
from Category_Income import BaseCategoryView  # Using shared base class

ASSETS_PATH = Path(__file__).parent / "assets_categories_expense"

class ExpenseCategoryView(BaseCategoryView):

    def _load_assets(self):
        """Load all expense category images"""
        # List of (image_file, category_name) pairs
        self.category_assets = [
            ("food.png", "Food"),
            ("transport.png", "Transport"),
            ("medicine.png", "Medicine"),
            ("groceries.png", "Groceries"),
            ("rent.png", "Rent"),
            ("gifts.png", "Gifts"),
            ("savings.png", "Savings"),
            ("entertainment.png", "Entertainment"),
            ("more.png", "More")
        ]
        
        # Load and store all images
        self.images = {}  # Clear any existing images
        for img_file, category in self.category_assets:
            try:
                img_path = ASSETS_PATH / img_file
                img = Image.open(img_path)
                self.images[category] = ImageTk.PhotoImage(img)
            except Exception as e:
                print(f"Error loading image {img_file}: {str(e)}")
                # Create blank image as fallback
                self.images[category] = ImageTk.PhotoImage(Image.new('RGBA', (100, 100), (0,0,0,0)))

    def _setup_view(self):
        """Create the expense category buttons grid"""
        # Positions for the 3x3 grid
        positions = [
            (45, 36), (175, 36), (302, 36),   # Row 1
            (45, 190), (175, 190), (302, 190), # Row 2
            (45, 343), (172, 343), (302, 343)  # Row 3
        ]
        
        # Create buttons for each category
        for (img_file, category), (x, y) in zip(self.category_assets, positions):
            self._create_category_button(category, x, y)

    def _create_category_button(self, category, x, y):
        """Create a category button with image"""
        btn = Button(
            self.parent_frame,
            image=self.images[category],
            command=lambda c=category: self._on_category_select(c),
            borderwidth=0,
            highlightthickness=0,
            activebackground="#DFF7E2",
            bg="#DFF7E2"
        )
        btn.image = self.images[category]
        btn.place(x=x, y=y)

    def _on_category_select(self, category):
        """Handle category selection"""
        self.clear_all_content()
        Controller.UIController.switch_category(
            self.parent_frame, 
            category, 
            self.username, 
            "Expense", 
            self.tab_instance
        )
        self.tab_instance.update_balance_labels()