# import customtkinter as ctk

# class MonthSelectorApp:
#     def __init__(self, root):
#         self.root = root
#         self.root.geometry("400x200")
#         self.root.title("CTk Month Selector")

#         # List of months
#         months = [
#             "January", "February", "March", "April", "May", "June",
#             "July", "August", "September", "October", "November", "December"
#         ]

#         # Create a dropdown (ComboBox)
#         self.month_combobox = ctk.CTkComboBox(
#             root,
#             values=months,
#             width=200,
#             font=("Poppins", 14),
#             state="readonly",
#             command=self.update_selected_month  # Correct method binding
#         )
#         self.month_combobox.pack(pady=20)

#         # Label to display selected month
#         self.selected_month_label = ctk.CTkLabel(root, text="Selected Month: None", font=("Poppins", 14))
#         self.selected_month_label.pack(pady=10)

#     def update_selected_month(self, selected_month):
#         self.selected_month_label.configure(text=f"Selected Month: {selected_month}")

# # Run the application
# if __name__ == "__main__":
#     root = ctk.CTk()
#     app = MonthSelectorApp(root)
#     root.mainloop()


# import customtkinter as ctk

# # Initialize the app
# app = ctk.CTk()
# app.geometry("300x200")

# # Function to update button text
# def update_button_text():
#     button.configure(text=entry.get())

# # Entry box
# entry = ctk.CTkEntry(app, placeholder_text="Type something...")
# entry.pack(pady=10)

# # Button
# button = ctk.CTkButton(app, text="Default Text")
# button.pack(pady=10)

# # Bind event so text updates when Enter key is pressed
# entry.bind("<Return>", lambda event: update_button_text())

# app.mainloop()



# import tkinter as tk
# import customtkinter as ctk
# import matplotlib.pyplot as plt
# from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# # Sample Data
# categories = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
# income = [500, 700, 650, 800, 750, 720, 810]
# expenses = [300, 450, 400, 500, 480, 460, 490]

# # Create main window
# root = ctk.CTk()
# root.geometry("300x240")  # Adjusted window size for wider layout
# root.title("Weekly Income vs Expenses")

# # Create a Frame to contain the graph (600x240)
# frame_chart = ctk.CTkFrame(root, width=300, height=240)
# frame_chart.pack(pady=20, padx=25)

# def create_bar_chart():
#     fig, ax = plt.subplots(figsize=(5, 2.5))  # Adjusted figure size for width increase
    
#     width = 0.3  # Bar width
#     x_positions = range(len(categories))

#     ax.bar([x - width/2 for x in x_positions], income, width, label="Income", color="#4CAF50")
#     ax.bar([x + width/2 for x in x_positions], expenses, width, label="Expenses", color="#F44336")

#     ax.set_xticks(x_positions)
#     ax.set_xticklabels(categories, fontsize=8)
#     ax.set_ylabel("Amount ($)", fontsize=9)
#     ax.set_title("Income vs Expenses", fontsize=11)
#     ax.legend(fontsize=9)

#     # Embed the graph inside the expanded frame
#     canvas_graph = FigureCanvasTkAgg(fig, master=frame_chart)
#     canvas_graph.draw()
#     canvas_graph.get_tk_widget().pack(fill=tk.BOTH, expand=True)

# # Generate the chart on startup
# create_bar_chart()

# # Run the Tkinter event loop
# root.mainloop()



import sqlite3 as sql
from abc import ABC, abstractmethod

class DatabaseInterface(ABC):
    @abstractmethod
    def connect(self):
        pass

    @abstractmethod
    def close_connection(self):
        pass

    @abstractmethod
    def register_user(self, username, password):
        pass

    @abstractmethod
    def authenticate_user(self, username, password):
        pass

    @abstractmethod
    def add_transaction(self, username, date, transaction_type, category, amount, title, description):
        pass

    @abstractmethod
    def add_notification(self, username, date, time, transaction_type, category, amount, message):
        pass

    @abstractmethod
    def update_password(self, username, new_password):
        pass

    @abstractmethod
    def delete_user(self, username):
        pass

    @abstractmethod
    def get_balance(self, username):
        pass
    
    @abstractmethod
    def fetch_total_income(self, username):
        pass

    @abstractmethod
    def fetch_total_expense(self, username):
        pass

    @abstractmethod
    def get_password(self, username):
        pass

    @abstractmethod
    def get_general_transactions(self, username):
        pass

    @abstractmethod
    def get_income_data(self, username):
        pass

    @abstractmethod
    def get_expense_data(self, username):
        pass

    @abstractmethod
    def get_data_notification(self, username):
        pass

class SQLiteDatabase(DatabaseInterface):
    def __init__(self, db_name="database.db"):
        self.db_name = db_name
        self.connection = None
        self.cursor = None
        self.connect()
        self._initialize_tables()

    def connect(self):
        """Establish database connection"""
        self.connection = sql.connect(self.db_name)
        self.cursor = self.connection.cursor()

    def _initialize_tables(self):
        """Initialize database tables"""
        tables = {
            'UserAuthentication': '''
                CREATE TABLE IF NOT EXISTS UserAuthentication (
                    username TEXT PRIMARY KEY,
                    password TEXT
                )''',
            'User_Transaction': '''
                CREATE TABLE IF NOT EXISTS User_Transaction (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT,
                    date TEXT,
                    transaction_type TEXT,
                    category TEXT,
                    amount INTEGER,
                    title TEXT,
                    description TEXT,
                    FOREIGN KEY (username) REFERENCES UserAuthentication(username)
                )''',
            'User_Income': '''
                CREATE TABLE IF NOT EXISTS User_Income (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT,
                    date TEXT,
                    category TEXT,
                    amount INTEGER,
                    title TEXT,
                    description TEXT,
                    FOREIGN KEY (username) REFERENCES UserAuthentication(username)
                )''',
            'User_Expense': '''
                CREATE TABLE IF NOT EXISTS User_Expense (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT,
                    date TEXT,
                    category TEXT,
                    amount INTEGER,
                    title TEXT,
                    description TEXT,
                    FOREIGN KEY (username) REFERENCES UserAuthentication(username)
                )''',
            'User_Notification': '''
                CREATE TABLE IF NOT EXISTS User_Notification (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT,
                    date TEXT,
                    time TEXT,
                    transaction_type TEXT,
                    category TEXT,
                    message TEXT,
                    description TEXT,
                    amount INTEGER,
                    FOREIGN KEY (username) REFERENCES UserAuthentication(username)
                )'''
        }
        
        for table_name, query in tables.items():
            self.cursor.execute(query)
        self.connection.commit()

    def register_user(self, username, password):
        """Register a new user"""
        try:
            self.cursor.execute(
                "INSERT INTO UserAuthentication (username, password) VALUES (?, ?)",
                (username, password)
            )
            self.connection.commit()
            return True
        except sql.IntegrityError:
            return False

    def authenticate_user(self, username, password):
        """Authenticate user credentials"""
        self.cursor.execute(
            "SELECT * FROM UserAuthentication WHERE username = ? AND password = ?",
            (username, password)
        )
        return bool(self.cursor.fetchall())

    def add_transaction(self, username, date, transaction_type, category, amount, title, description):
        """Add a new transaction"""
        try:
            # Add to specific transaction type table
            if transaction_type.lower() == 'income':
                table = 'User_Income'
            elif transaction_type.lower() == 'expense':
                table = 'User_Expense'
            else:
                return False

            self.cursor.execute(
                f'''
                INSERT INTO {table} (username, date, category, amount, title, description)
                VALUES (?, ?, ?, ?, ?, ?)
                ''',
                (username, date, category, amount, title, description)
            )

            # Add to general transaction table
            self.cursor.execute(
                '''
                INSERT INTO User_Transaction (username, date, transaction_type, category, amount, title, description)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ''',
                (username, date, transaction_type, category, amount, title, description)
            )

            self.connection.commit()
            return True
        except sql.Error as e:
            print(f"Database error: {str(e)}")
            return False

    def add_notification(self, username, date, time, transaction_type, category, message, description, amount):
        try:

            self.cursor.execute(
                f'''
                INSERT INTO  User_Notification (username, date, time, transaction_type, category, message, description, amount)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''',
                (username, date, time, transaction_type, category, message, description, amount)
                )

            self.connection.commit()
            return True
        except sql.Error as e:
            print(f"Database error: {str(e)}")
            return False
        
    def get_data_notification(self, username):
        try:
            self.cursor.execute(
                "SELECT date, time, category, message, description, amount FROM User_Notification WHERE username = ?",
                (username,)
            )
            return self.cursor.fetchall()
        except sql.Error as e:
            print(f"Database error: {str(e)}")
            return []
        
    def get_general_transactions(self, username):
        """Get all transactions for a user"""
        try:
            self.cursor.execute(
                "SELECT username, date, transaction_type, category, amount, title, description FROM User_Transaction WHERE username = ?",
                (username,)
            )
            return self.cursor.fetchall()
        except sql.Error as e:
            print(f"Database error: {str(e)}")
            return []
        
    def get_income_data(self, username):
        try:
            self.cursor.execute(
                "SELECT username, date, category, amount, title, description FROM User_Income WHERE username = ?",
                (username,)
            )
            return self.cursor.fetchall()
        except sql.Error as e:
            print(f"Database error: {str(e)}")
            return []
        
    def get_expense_data(self, username):
        try:
            self.cursor.execute(
                "SELECT username, date, category, amount, title, description FROM User_Expense WHERE username = ?",
                (username,)
            )
            return self.cursor.fetchall()
        except sql.Error as e:
            print(f"Database error: {str(e)}")
            return []

    def update_password(self, username, new_password):
        """Update user password"""
        try:
            self.cursor.execute(
                "UPDATE UserAuthentication SET password = ? WHERE username = ?",
                (new_password, username)
            )
            self.connection.commit()
            return True
        except sql.Error as e:
            print(f"Database error: {str(e)}")
            return False

    def delete_user(self, username):
        """Delete user and all associated data"""
        try:
            tables = ['UserAuthentication', 'User_Transaction', 'User_Income', 'User_Expense']
            for table in tables:
                self.cursor.execute(f"DELETE FROM {table} WHERE username = ?", (username,))
            self.connection.commit()
            return True
        except sql.Error as e:
            print(f"Database error: {str(e)}")
            return False

    def get_balance(self, username):
        """Calculate user balance (income - expenses)"""
        try:
            income = self._get_transaction_total('User_Income', username)
            expenses = self._get_transaction_total('User_Expense', username)
            return income - expenses
        except sql.Error as e:
            print(f"Database error: {str(e)}")
            return 0

    def fetch_total_income(self, username):
        try:
            income = self._get_transaction_total('User_Income', username)
            return income
        except sql.Error as e:
             print(f"Database error: {str(e)}")
             return 0
        
    def fetch_total_expense(self, username):
        try:
            expense = self._get_transaction_total('User_Expense', username)
            return expense
        except sql.Error as e:
             print(f"Database error: {str(e)}")
             return 0
        
    def get_password(self, username):
        self.cursor.execute("SELECT password FROM UserAuthentication WHERE username = ?",(username,))
        return self.cursor.fetchone()[0]

    def _get_transaction_total(self, table, username):
        """Helper method to get transaction totals"""
        self.cursor.execute(
            f"SELECT SUM(amount) FROM {table} WHERE username = ?",
            (username,)
        )
        return self.cursor.fetchone()[0] or 0
    
    def close_connection(self):
        """Close database connection"""
        if self.connection:
            self.connection.close()

class DatabaseService:
    """Singleton service for database access"""
    _instance = None

    @classmethod
    def get_instance(cls, db_name="database.db"):
        if cls._instance is None:
            cls._instance = SQLiteDatabase(db_name)
        return cls._instance