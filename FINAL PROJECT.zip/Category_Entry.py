# from pathlib import Path
# from tkinter import *
# import customtkinter as ctk
# from PIL import Image, ImageTk
# from datetime import datetime
# import Controller

# ASSETS_PATH = Path(__file__).parent / "assets_categories_entry"

# class Category_Entry:
#     def __init__(self, Income_Expense_Frame, category, frames, username, categories_tab_instance):
#         self.Income_Expense_Frame = Income_Expense_Frame
#         self.category = category
#         self.frames = frames
#         self.username = username
#         self.categories_tab_instance = categories_tab_instance
#         self.images = {}
#         self.entries = {}
#         self.load_entry_widgets() 

#     def load_image(self, image_name, size):
#         img = Image.open(ASSETS_PATH / image_name)
#         return ImageTk.PhotoImage(img)

#     def clear_all_content(self):
#         for widget in self.Income_Expense_Frame.winfo_children():
#             widget.destroy()

#     def back_button(self):
#         self.clear_all_content()
        
#         if self.frames == "Income":
#             from Category_Income import Category_Incomes
#             self.Income_Expense_Frame.configure(fg_color="#DFF7E2")
#             Category_Incomes(self.Income_Expense_Frame, self.username, self.categories_tab_instance)
#         elif self.frames == "Expense":
#             from Category_Expense import Category_Expenses
#             self.Income_Expense_Frame.configure(fg_color="#DFF7E2")
#             Category_Expenses(self.Income_Expense_Frame, self.username, self.categories_tab_instance)

#     def save_entry(self):
#         data = {key: entry.get("1.0", "end-1c") if key == "description" else entry.get() for key, entry in self.entries.items()}
        
#         Controller.Controller.add_transaction(
#             self.username, 
#             data.get('date', ''), 
#             self.frames, 
#             self.category, 
#             data.get('amount', ''), 
#             data.get('title', ''), 
#             data.get('description', '')
#         )
        
#         self.categories_tab_instance.update_balance_labels()
#         self.back_button()

#     def load_entry_widgets(self):
#         # Change background color of the main frame
#         self.Income_Expense_Frame.configure(fg_color="#D7E6C5")

#         # Back Button
#         self.images['button_back'] = self.load_image("button_back.png", (45, 45))
#         button_back = Button(self.Income_Expense_Frame, image=self.images['button_back'],
#                              command=self.back_button, borderwidth=0, activebackground="#D7E6C5", bg="#D7E6C5",
#                              cursor="hand2")
#         button_back.place(x=20, y=25)

#         # Entry Fields with image backgrounds
#         fields = [
#             ("date", "Date", 99, 69, 35),
#             ("amount", "Amount", 182, 150, 35),
#             ("title", "Title", 265, 233, 35),
#             ("description", "Description", 350, 317, 54),
#         ]

#         for key, label_text, y_entry, y_label, height in fields:
#             entry_frame = Frame(self.Income_Expense_Frame, bg="#D7E6C5")
#             entry_frame.place(x=53, y=y_entry, width=334, height=height)

#             # Ensure background image fully covers the entry area
#             self.images[key] = self.load_image(f"{key}.png", (334, height))
#             bg_label = Label(entry_frame, image=self.images[key], bg="#D7E6C5")
#             bg_label.pack(fill="both", expand=True)
            
#             if key == "description":
#                 entry_widget = Text(entry_frame, borderwidth=0, highlightthickness=0, 
#                                     bg="#F1FFF3", fg="black", font=("Inter", 10),
#                                     wrap=WORD)
#                 entry_widget.place(x=12, y=10, width=310, height=height - 10)
#             else:
#                 entry_widget = Entry(entry_frame, borderwidth=0, highlightthickness=0,
#                                     bg="#F1FFF3", fg="black", font=("Inter", 10))
#                 entry_widget.place(x=12, y=5, width=310, height=height - 12)
#                 self.entries[key] = entry_widget

#                 if key == "date":
#                     current_date = datetime.now().strftime("%Y-%m-%d")
#                     entry_widget.insert(0, current_date)

#             field_label = ctk.CTkLabel(self.Income_Expense_Frame, text=label_text, 
#                                     font=("Inter Medium", 18, "bold"), text_color="black")
#             field_label.place(x=60, y=y_label)  # ✅ Better positioning for field label


#         # Save Button
#         self.images['button_save'] = self.load_image("button_save.png", (130, 50))
#         button_save = Button(self.Income_Expense_Frame, image=self.images['button_save'], 
#                            borderwidth=0, activebackground="#D7E6C5", bg="#D7E6C5",
#                            command=self.save_entry, cursor="hand2")
#         button_save.place(x=155, y=425)



from pathlib import Path
from tkinter import Text, Entry, Button
import customtkinter as ctk
from PIL import Image, ImageTk
from datetime import datetime
import pygame
import Controller
from abc import ABC, abstractmethod

ASSETS_PATH = Path(__file__).parent / "assets_categories_entry"
NOTIF_PATH = Path(__file__).parent / "assets_notification"

class BaseEntryForm(ABC):
    """Abstract base class for entry forms (Abstraction)"""
    def __init__(self, parent_frame, category, transaction_type, username, tab_instance):
        self.parent_frame = parent_frame
        self.category = category
        self.transaction_type = transaction_type
        self.username = username
        self.tab_instance = tab_instance
        self.images = {}
        self.entries = {}
        self._setup_form()

    @abstractmethod
    def _setup_form(self):
        pass

    @abstractmethod
    def _create_form_fields(self):
        pass

    @abstractmethod
    def _create_save_button(self):
        pass

    def clear_all_content(self):
        """Clear all widgets from parent frame"""
        for widget in self.parent_frame.winfo_children():
            widget.destroy()

class CategoryEntryForm(BaseEntryForm):
    """Concrete entry form implementation (Inheritance)"""
    def _setup_form(self):
        """Setup the complete entry form (Encapsulation)"""
        self.parent_frame.configure(fg_color="#D7E6C5")
        self._create_back_button()
        self._create_form_fields()
        self._create_save_button()

    def _create_back_button(self):
        """Create back navigation button"""
        self.images['back'] = ImageTk.PhotoImage(
            Image.open(ASSETS_PATH / "button_back.png").resize((45, 45))
        )
        Button(
            self.parent_frame,
            image=self.images['back'],
            command=self._navigate_back,
            borderwidth=0,
            bg="#D7E6C5",
            activebackground="#D7E6C5",
            cursor="hand2"
        ).place(x=20, y=25)

    def _create_form_fields(self):
        """Create all form input fields"""
        fields = [
            ("date", "Date", 99, 69, 35, self._create_date_entry),
            ("amount", "Amount", 182, 150, 35, self._create_numeric_entry),
            ("title", "Title", 265, 233, 35, self._create_text_entry),
            ("description", "Description", 350, 317, 54, self._create_description_entry)
        ]

        for field in fields:
            self._create_field(*field)

    def _create_field(self, key, label, y_entry, y_label, height, creator_fn):
        """Create a form field with label"""
        # Field label
        ctk.CTkLabel(
            self.parent_frame,
            text=label,
            font=("Inter Medium", 18, "bold")
        ).place(x=60, y=y_label)

        # Field background
        frame = ctk.CTkFrame(
            self.parent_frame,
            width=334,
            height=height,
            fg_color="#F1FFF3",
            corner_radius=8
        )
        frame.place(x=53, y=y_entry)

        # Field input
        self.entries[key] = creator_fn(frame)

    def _create_date_entry(self, parent):
        """Create date entry field"""
        entry = Entry(
            parent,
            borderwidth=0,
            font=("Inter", 10),
            bg="#F1FFF3"
        )
        entry.insert(0, datetime.now().strftime("%Y-%m-%d"))
        entry.place(x=12, y=5, width=310, height=25)
        return entry

    def _create_numeric_entry(self, parent):
        return self._create_text_entry(parent)

    def _create_text_entry(self, parent):
        entry = Entry(
            parent,
            borderwidth=0,
            font=("Inter", 10),
            bg="#F1FFF3"
        )
        entry.place(x=12, y=5, width=310, height=25)
        return entry

    def _create_description_entry(self, parent):
        text = Text(
            parent,
            borderwidth=0,
            font=("Inter", 10),
            bg="#F1FFF3",
            wrap="word"
        )
        text.place(x=12, y=10, width=310, height=34)
        return text

    def _create_save_button(self):
        self.images['save'] = ImageTk.PhotoImage(
            Image.open(ASSETS_PATH / "button_save.png").resize((130, 50))
        )
        Button(
            self.parent_frame,
            image=self.images['save'],
            command=self._save_transaction,
            borderwidth=0,
            bg="#D7E6C5",
            activebackground="#D7E6C5",
            cursor="hand2"
        ).place(x=155, y=425)

    def _save_transaction(self):

        data = {
            'date': self.entries['date'].get(),
            'amount': self.entries['amount'].get(),
            'title': self.entries['title'].get(),
            'description': self.entries['description'].get("1.0", "end-1c")
        }

        Controller.Controller.add_transaction(
            self.username,
            data['date'],
            self.transaction_type,
            self.category,
            data['amount'],
            data['title'],
            data['description']
        )

        self.NotificationGenerator()
        self.tab_instance.update_balance_labels()
        self._navigate_back()

    def NotificationGenerator(self):

        self.current_time = datetime.now().strftime("%H:%M")
        self.current_date = datetime.now().strftime("%Y-%m-%d")

        data = {
            'amount': self.entries['amount'].get()
        }

        Controller.Controller.Notification_Handler(
            username=self.username, 
            date=self.current_date, 
            time=self.current_time, 
            transaction_type=self.transaction_type, 
            category=self.category, 
            amount=data['amount'],
            message=None,
            description=None
            )

        pygame.mixer.init()
        pygame.mixer.Sound(NOTIF_PATH / "notif.wav").play()

    def _navigate_back(self):
        """Navigate back to category view (Polymorphism)"""
        if self.transaction_type == "Income":
            self.clear_all_content()
            from Category_Income import IncomeCategoryView
            view_class = IncomeCategoryView
        else:
            self.clear_all_content()
            from Category_Expense import ExpenseCategoryView
            view_class = ExpenseCategoryView

        self.parent_frame.configure(fg_color="#DFF7E2")
        view_class(self.parent_frame, self.username, self.tab_instance)

















