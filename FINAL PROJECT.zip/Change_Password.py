import customtkinter as ctk
from pathlib import Path
from PIL import Image
import Controller
from tkinter import END, Entry, Button, messagebox, PhotoImage

ASSETS_PATH = Path(__file__).parent / "assets_change_password"

class ChangePassword:
    def __init__(self, current_frame, username, settings_handler):
        self.current_frame = current_frame
        self.username = username
        self.settings_handler = settings_handler  # Store the instance
        self.entry_widgets = {}
        self.images = {}
        self.password_visible = {
            "new_password": False,
            "confirm_password": False
        }

        self.change_password(self.current_frame)

    def load_image(self, filename, size):
        image_path = ASSETS_PATH / filename
        if not image_path.exists():
            print(f"Image file not found: {image_path}")
            return None
        pil_image = Image.open(image_path)
        return ctk.CTkImage(light_image=pil_image, size=size)

    def toggle_password_visibility(self, field_name):
        if field_name in self.password_visible:
            entry = self.entry_widgets[field_name]
            current_text = entry.get()
            
            # Toggle visibility state
            self.password_visible[field_name] = not self.password_visible[field_name]
            
            # Clear and reconfigure entry
            entry.delete(0, END)
            if self.password_visible[field_name]:
                entry.config(show="")  # Show text
            else:
                entry.config(show="*")  # Hide text with asterisks
            
            # Restore text
            entry.insert(0, current_text)

    def change_password(self, current_frame):
        current_frame.configure(cursor="arrow")
        for widget in current_frame.winfo_children():
            widget.destroy()

        # Back Button
        self.images['back_button'] = self.load_image("back_button.png", (38, 40))
        if self.images['back_button']:
            back_button = ctk.CTkLabel(current_frame, text="", image=self.images['back_button'])
            back_button.place(x=9, y=10)

        # Entry Fields with Background Images
        fields = [
            ("current_password", "Current Password", 74),
            ("new_password", "New Password", 147),
            ("confirm_password", "Confirm Password", 227)
        ]

        for key, label_text, y_pos in fields:
            self.images[key] = self.load_image("entry_box.png", (276, 32))

            if self.images[key]:  # Prevent errors if image loading fails
                bg_label = ctk.CTkLabel(current_frame, text="", image=self.images[key])
                bg_label.place(x=31, y=y_pos)

            # Configure entry widget with password masking for new and confirm password
            show_char = "*" if key in ["new_password", "confirm_password"] else ""
            entry_widget = Entry(current_frame, font=("Inter", 12 * -1), bd=0, bg="#F1FFF3", show=show_char)
            entry_widget.place(x=40, y=y_pos + 5, width=258, height=22)
            self.entry_widgets[key] = entry_widget

            field_label = ctk.CTkLabel(current_frame, text=label_text, font=("Inter Medium", 12, "bold"), text_color="black")
            field_label.place(x=34, y=y_pos - 28)

        # Show password buttons with click functionality
        self.images['show_password'] = self.load_image("show_password.png", (25, 25))

        # New password show button (with toggle functionality)
        if self.images['show_password']:
            show_new_password = ctk.CTkLabel(current_frame, text="", image=self.images['show_password'], bg_color="#F1FFF3")
            show_new_password.place(x=270, y=151)
            show_new_password.bind("<Button-1>", lambda e: self.toggle_password_visibility("new_password"))
            show_new_password.bind("<Enter>", lambda e: current_frame.configure(cursor="hand2"))
            show_new_password.bind("<Leave>", lambda e: current_frame.configure(cursor=""))

        # Confirm password show button (with toggle functionality)
        if self.images['show_password']:
            show_confirm_password = ctk.CTkLabel(current_frame, text="", image=self.images['show_password'], bg_color="#F1FFF3")
            show_confirm_password.place(x=270, y=231)
            show_confirm_password.bind("<Button-1>", lambda e: self.toggle_password_visibility("confirm_password"))
            show_confirm_password.bind("<Enter>", lambda e: current_frame.configure(cursor="hand2"))
            show_confirm_password.bind("<Leave>", lambda e: current_frame.configure(cursor=""))

        # Check Password Button
        image_path = ASSETS_PATH / "button_password.png"
        self.images['button_password'] = PhotoImage(file=image_path)  # Use PhotoImage

        if self.images['button_password']:
            button_password = Button(
                current_frame, 
                image=self.images['button_password'], 
                borderwidth=0, 
                activebackground="#CFF6CD", 
                bg="#CFF6CD", 
                command=self.submit_password_change
            )
            button_password.place(x=87, y=274)

        back_button.bind("<Button-1>", lambda e: self.on_click_back())
        back_button.bind("<Enter>", lambda e: current_frame.configure(cursor="hand2"))
        back_button.bind("<Leave>", lambda e: current_frame.configure(cursor=""))

    def on_click_back(self):
        self.current_frame.configure(cursor="arrow")

        for widget in self.current_frame.winfo_children():
            widget.unbind("<Enter>")
            widget.unbind("<Leave>")

        self.settings_handler.setting_features()

    def submit_password_change(self):
        current_password = self.entry_widgets["current_password"].get()
        new_password = self.entry_widgets["new_password"].get()
        confirm_password = self.entry_widgets["confirm_password"].get()

        # Check if all fields are filled
        if not current_password or not new_password or not confirm_password:
            messagebox.showwarning("Warning", "All fields are required!")
            return

        # Get the stored password for the user
        password = Controller.Controller.get_password(self.username)

        # Check if current password is correct
        if password != current_password:
            messagebox.showerror("Error", "Current password is incorrect!")
            return

        # Check if new password and confirm password match
        if new_password != confirm_password:
            messagebox.showerror("Error", "New password and confirm password do not match!")
            return

        # All validations passed, try to change the password
        try:
            results = Controller.Controller.update_password(self.username, new_password)
            
            if results:
                messagebox.showinfo("Success", "Password changed successfully!")
                self.on_click_back()
            else:
                messagebox.showerror("Error", "Failed to update password!")
        except Exception as e:
            messagebox.showerror("Database Error", f"Error changing password: {e}")









































































# import customtkinter as ctk
# from pathlib import Path
# from PIL import Image
# import Controller, Change_Password
# from tkinter import Entry

# ASSETS_PATH = Path(__file__).parent / "assets_change_password"

# class ChangePassword:
#     def __init__(self, current_frame, username):
#         self.current_frame = current_frame
#         self.username = username
#         self.settings_frame_features = None
#         self.settings_visible = False
#         self.images = {}
#         self.Change_Password(self.current_frame)

#     def load_image(self, filename, size):
#         try:
#             image_path = ASSETS_PATH / filename
#             if not image_path.exists():
#                 print(f"Image file not found: {image_path}")
#                 return None
#             pil_image = Image.open(image_path)
#             return ctk.CTkImage(light_image=pil_image, size=size)
#         except Exception as e:
#             print(f"Error loading image {filename}: {e}")
#             return None

#     def Change_Password(self, current_frame):
#         for widget in self.current_frame.winfo_children():
#             widget.destroy()

#         # Back button
#         self.images['back_button'] = self.load_image("back_button.png", (276, 32))
#         if self.images['back_button']:
#             back_button = ctk.CTkLabel(self.current_frame, text="", image=self.images['back_button'])
#             back_button.place(x=9, y=10)
        
#         # Current Password Label and Entry
#         current_password_label = ctk.CTkLabel(self.current_frame, text="Current Password", font=("Inter Medium", 12, "bold"), text_color="black")
#         current_password_label.place(x=31, y=54)
        
#         self.images['entry_box1'] = self.load_image("entry_box.png", (276, 32))
#         current_password_entry = Entry(self.current_frame, show="*", font=("Inter", 12), bd=0, highlightthickness=0)
#         current_password_entry.place(x=31, y=74, width=276, height=32)
        
#         # New Password Label and Entry
#         new_password_label = ctk.CTkLabel(self.current_frame, text="New Password", font=("Inter Medium", 12, "bold"), text_color="black")
#         new_password_label.place(x=31, y=124)
        
#         self.images['entry_box2'] = self.load_image("entry_box.png", (276, 32))
#         new_password_entry = Entry(self.current_frame, show="*", font=("Inter", 12), bd=0, highlightthickness=0)
#         new_password_entry.place(x=31, y=144, width=276, height=32)
        
#         # Confirm Password Label and Entry
#         confirm_password_label = ctk.CTkLabel(self.current_frame, text="Confirm Password", font=("Inter Medium", 12, "bold"), text_color="black")
#         confirm_password_label.place(x=31, y=194)
        
#         self.images['entry_box3'] = self.load_image("entry_box.png", (276, 32))
#         confirm_password_entry = Entry(self.current_frame, show="*", font=("Inter", 12), bd=0, highlightthickness=0)
#         confirm_password_entry.place(x=31, y=214, width=276, height=32)
        
#         # Submit button (optional - you can customize this)
#         submit_button = ctk.CTkButton(
#             self.current_frame,
#             text="Change Password",
#             font=("Inter Medium", 12, "bold"),
#             width=276,
#             height=32,
#             command=lambda: self.submit_password_change(
#                 current_password_entry.get(),
#                 new_password_entry.get(),
#                 confirm_password_entry.get()
#             )
#         )
#         submit_button.place(x=31, y=264)
        
#         # Store references to entries for later use
#         self.current_password_entry = current_password_entry
#         self.new_password_entry = new_password_entry
#         self.confirm_password_entry = confirm_password_entry

#     def submit_password_change(self, current_password, new_password, confirm_password):
#         # Add your password change logic here
#         if not current_password or not new_password or not confirm_password:
#             print("All fields are required")
#             return
        
#         if new_password != confirm_password:
#             print("New password and confirm password do not match")
#             return
        
#         # Call your controller method to change password
#         try:
#             # Controller.change_password(self.username, current_password, new_password)
#             print(f"Password change requested for user: {self.username}")
#         except Exception as e:
#             print(f"Error changing password: {e}")