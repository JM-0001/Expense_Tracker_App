from pathlib import Path
from tkinter import Button
from PIL import Image, ImageTk
import Controller
import customtkinter as ctk
from abc import ABC, abstractmethod

ASSETS_PATH = Path(__file__).parent / "assets_analysis"

class BaseCategoryView():
    """Abstract base class for category views (Abstraction)"""
    def __init__(self, parent_frame, username, tab_instance):
        self.parent_frame = parent_frame
        self.username = username
        self.tab_instance = tab_instance
        self.images = {}
        self._initialize_view()

    def _initialize_view(self):
        """Initialize the view by loading images and creating the display area"""
        self._load_images()
        self._create_analysis_display_area()

    def clear_all_content(self):
        """Clear all widgets from parent frame"""
        for widget in self.parent_frame.winfo_children():
            widget.destroy()

class AnalysisExpenseView(BaseCategoryView):

    def _load_images(self):
        """Load all required images without resizing"""
        self.images['bar_graph'] = self._load_tk_image("bar_graph.png")
        self.images['pie_chart'] = self._load_tk_image("pie_chart.png")

    def _load_tk_image(self, image_name):
        """Load images using ImageTk for tkinter without resizing"""
        img_path = ASSETS_PATH / image_name
        img = Image.open(img_path)
        return ImageTk.PhotoImage(img)

    def _create_analysis_display_area(self):
        """Create the analysis display area with graphs"""
        self.graph_label = ctk.CTkLabel(
            self.parent_frame,
            text="Graphical Representation of Data",
            font=("Poppins", 18, "bold")
        )
        self.graph_label.place(x=23, y=19)

        self.Income_Expense_Frame = ctk.CTkFrame(
            self.parent_frame,
            corner_radius=26,
            width=440,
            height=400,
            fg_color="#DFF7E2",
            bg_color="#9FD39C"
        )
        self.Income_Expense_Frame.place(x=25, y=54)

        self.bar_graph_image = Button(
            self.parent_frame,
            image=self.images['bar_graph'],
            bd=0,
            bg="#9FD39C",
            activebackground="#9FD39C",
            relief="flat",
            command=self.bar_graph
        )
        self.bar_graph_image.place(x=16, y=461)

        self.pie_chart_image = Button(
            self.parent_frame,
            image=self.images['pie_chart'],
            bd=0,
            bg="#9FD39C",
            activebackground="#9FD39C",
            relief="flat",
            command=self.pie_chart
        )
        self.pie_chart_image.place(x=245, y=461)


    def bar_graph(self):
        # PURPOSE:
        # This function will generate a bar graph showing the user's expense categories.
        # For example: Food, Utilities, Transport, etc., with corresponding amounts.

        # NOTE: Use this to get the user's expense data
        # NOTE: you can use matplotlib to generate the graph
        # expense_data = Controller.Controller.get_expense_data(self.username)

        pass  # Remove this when the function is implemented

    def pie_chart(self):
        # PURPOSE:
        # This function will generate a pie chart showing the percentage distribution
        # of the user's expenses by category—visually illustrating how much each category consumes.

        # NOTE: Use this to get the user's expense data
        # NOTE: you can use matplotlib to generate the graph
        # expense_data = Controller.Controller.get_expense_data(self.username)

        pass  # Remove this when the function is implemented


