import matplotlib.pyplot as plt
import pandas as pd
from pathlib import Path
from tkinter import Button
from PIL import Image, ImageTk
import Controller

ASSETS_PATH = Path(__file__).parent / "assets_analysis"

class BaseCategoryView():
    """Abstract base class for category views (Abstraction)"""
    def __init__(self, parent_frame, username, tab_instance):
        self.parent_frame = parent_frame
        self.username = username
        self.tab_instance = tab_instance
        self.images = {}
        self._initialize_view()

    def _initialize_view(self):
        """Initialize the view by loading images and creating the display area"""
        self._load_images()
        self._create_analysis_display_area()

    def clear_all_content(self):
        """Clear all widgets from parent frame"""
        for widget in self.parent_frame.winfo_children():
            widget.destroy()

class AnalysisIncomeView(BaseCategoryView):

    def _load_images(self):
        """Load all required images without resizing"""
        self.images['bar_graph'] = self._load_tk_image("bar_graph.png")
        self.images['pie_chart'] = self._load_tk_image("pie_chart.png")

    def _load_tk_image(self, image_name):
        """Load images using ImageTk for tkinter without resizing"""
        img_path = ASSETS_PATH / image_name
        img = Image.open(img_path)
        return ImageTk.PhotoImage(img)

    def _create_analysis_display_area(self):
        """Create the analysis display area with graphs"""
        self.graph_label = ctk.CTkLabel(
            self.parent_frame,
            text="Graphical Representation of Data",
            font=("Poppins", 18, "bold")
        )
        self.graph_label.place(x=23, y=19)

        self.Income_Expense_Frame = ctk.CTkFrame(
            self.parent_frame,
            corner_radius=26,
            width=440,
            height=400,
            fg_color="#DFF7E2",
            bg_color="#9FD39C"
        )
        self.Income_Expense_Frame.place(x=25, y=54)

        self.bar_graph_image = Button(
            self.parent_frame,
            image=self.images['bar_graph'],
            bd=0,
            bg="#9FD39C",
            activebackground="#9FD39C",
            relief="flat",
            command=self.bar_graph
        )
        self.bar_graph_image.place(x=16, y=461)


        self.pie_chart_image = Button(
            self.parent_frame,
            image=self.images['pie_chart'],
            bd=0,
            bg="#9FD39C",
            activebackground="#9FD39C",
            relief="flat",
            command=self.pie_chart
        )
        self.pie_chart_image.place(x=245, y=461)



    def pie_chart(self):
        #Generate and display a pie chart for income distribution
        income_data = Controller.get_income_data(self.username)

        if not income_data:
            print("No income data available.")
            return
        
COLORS = {
            'Salary': '#9fd39c',    
            'Investment': "#a6dfa3", 
            'Allowance': "#a3e8a2",  
            'Bonus': '#dff7e2',    
            'Dividend': "#b1e8ae",   
            'Gifts': "#bfeec3",      
            'Borrowing': "#bef6bb",  
            'More': "#9ac798"       
            }

class Transaction:
    def __init__(self, category, amount, type_):
        self.category = category
        self.amount = amount
        self.type = type_

# Transaction data
transactions = [
    Transaction('Salary', 8000, 'income'),
    Transaction('Investment', 0, 'income'),
    Transaction('Bonus', 500, 'income'),
    Transaction('Dividend', 0, 'income'),
    Transaction('Gifts', 500, 'income'),
    Transaction('Borrowing', 0, 'income'),
    Transaction('Allowance', 1000, 'income'),
    Transaction('More', 0, 'income'),
] # or Transaction_Income

# Filter and process income transactions, excluding zero amounts
income_data = {t.category: t.amount for t in transactions if t.type == "income" and t.amount > 0}

chart_data = pd.DataFrame(list(income_data.items()), columns=['Category', 'Amount'])

# Plot pie chart
plt.figure(figsize=(6, 6))
plt.pie(chart_data['Amount'], labels=chart_data['Category'], 
        autopct='%1.1f%%', colors=[COLORS[cat] for cat in chart_data['Category']],
        shadow=True, startangle=340, explode=[0.1 if cat == 'Salary' else 0.01 for cat in chart_data['Category']])
plt.title("Income Breakdown")
plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
plt.show()