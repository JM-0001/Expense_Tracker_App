import matplotlib.pyplot as plt
import pandas as pd

# Define transaction categories and colors
COLORS = {
    'Salary': '#3B82F6',    # Blue
    'Investment': '#10B981', # Green
    'Bonus': '#F59E0B',      # Yellow
    'Receipt': '#EF4444',    # Red
    'Dividend': '#8B5CF6',   # Purple
    'Gifts': '#EC4899',      # Pink
    'Borrowing': '#F97316',  # Orange
    'Allowance': '#6B7280',  # Gray
    'More': '#14B8A6'        # Teal
}

class Transaction:
    def __init__(self, category, amount, type_):
        self.category = category
        self.amount = amount
        self.type = type_

# Sample transaction data
transactions = [
    Transaction('Salary', 2500, 'income'),
    Transaction('Investment', 1200, 'income'),
    Transaction('Bonus', 800, 'income'),
    Transaction('Receipt', 300, 'income'),
    Transaction('Dividend', 500, 'income'),
    Transaction('Gifts', 200, 'income'),
    Transaction('Borrowing', 400, 'income'),
    Transaction('Allowance', 150, 'income')
]

# Filter and process income transactions
income_data = {}
for t in transactions:
    if t.type == "income":
        income_data[t.category] = income_data.get(t.category, 0) + t.amount

chart_data = pd.DataFrame(list(income_data.items()), columns=['Category', 'Amount'])

# Plot the pie chart
plt.figure(figsize=(6, 6))
plt.pie(chart_data['Amount'], labels=chart_data['Category'], 
        autopct='%1.1f%%', colors=[COLORS[cat] for cat in chart_data['Category']])
plt.title("Income Breakdown")
plt.show()
